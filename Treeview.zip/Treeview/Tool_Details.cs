﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace FS_1
{
    public class Tool_Details: CustomTreeViewItem
    {
        public string ToolName { get; set; }
        public string VendorName { get; set; }
        public string VersionNo { get; set; }
        public string UsageEnvironment { get; set; }
        public string PurchaseDate { get; set; }
        public string InstallationDate { get; set; }
        public string MaintenanceContract { get; set; }
        public string Purpose { get; set; }
        public string ProjectInputs { get; set; }
        public string UserManuals { get; set; }
        public string TestReports { get; set; }

        public void AddTDToTool(TreeViewItem ParentNode)
        {
            TreeViewItem AddTD = new TreeViewItem { Header = "Project_Name", Uid =""};
            ParentNode.Items.Add(AddTD);
        }

    }

}
