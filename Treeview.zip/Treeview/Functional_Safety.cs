﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Windows.Controls;

namespace FS_1
{
    public class Functional_Safety : CustomTreeViewItem

    {
        public new string Header { get; set; }

        private ObservableCollection<Project> _projectCollection;
        public ObservableCollection<Project> ProjectCollection
        { get { return _projectCollection; }
            set
            {
                if (_projectCollection != value)
                    _projectCollection = value;
                OnPropertyChanged("ProjectCollection");
            }
            
        }
        public Functional_Safety()
        {
            ProjectCollection = GetProjectCollection();
            //return ProjectCollection;
        }

        public ObservableCollection<Project> GetFS()
        {
            ProjectCollection = GetProjectCollection();
            return ProjectCollection;
        }
        ObservableCollection<Sheets> GetSheetsCollection()
        {
            ObservableCollection<Sheets> SheetsList = new ObservableCollection<Sheets>();
            Sheets InsSheets = new Sheets();
            SheetsList.Add(new Sheets() { Header = InsSheets.SummaryObjects.Header });
            SheetsList.Add(new Sheets() { Header = InsSheets.RevisionHistoryObjects.Header });
            SheetsList.Add(new Sheets() { Header = InsSheets.AnalysisSummaryObjects.Header });
            SheetsList.Add(new Sheets() { Header = InsSheets.ToolDetailsObjects.Header });
            SheetsList.Add(new Sheets() { Header = InsSheets.FeatureObjects.Header });
            return SheetsList;
        }

        ObservableCollection<Tool> GetToolcollection()
        {
            ObservableCollection<Sheets> InsSheetsCollection = GetSheetsCollection();
            ObservableCollection<Tool> InsToolCollection = new ObservableCollection<Tool>
            {
                new Tool() { Header = "RTE TestCaseGenerator", ToolName = "RTE TCG", SheetsCollection = InsSheetsCollection },
                new Tool() {Header = "RTE Code Generator", ToolName = "RTE CG", SheetsCollection = InsSheetsCollection}
            };
            return InsToolCollection;
        }

        ObservableCollection<Selectactivity> GetSelectactivitiesCollection()
        {
            ObservableCollection<Sheets> InsSheetsCollection = GetSheetsCollection();
            ObservableCollection<Tool> InsToolCollection = GetToolcollection();
            ObservableCollection<Selectactivity> InsSelectActivitiesCollection = new ObservableCollection<Selectactivity>
            {
                new Selectactivity() {Header = "TCL", ToolsCollection = InsToolCollection}
            };
            return InsSelectActivitiesCollection;
        }

        ObservableCollection<Project> GetProjectCollection()
        {
            ObservableCollection<Sheets> InsSheetsCollection = GetSheetsCollection();
            ObservableCollection<Tool> InsToolCollection = GetToolcollection();
            ObservableCollection<Selectactivity> InsSelectActivitiesCollection = GetSelectactivitiesCollection();
            ObservableCollection<Project> InsProjectCollection = new ObservableCollection<Project>();
            {
                new Project() { Header = "Safe RTE", ActivityCollection = InsSelectActivitiesCollection };
            }
            return InsProjectCollection;
        }
    }

}      

