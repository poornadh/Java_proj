﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace FS_1
{
    public interface IProject
    {
        TreeViewItem PopulateNode(TreeViewItem ParentNode);

        void PopulateNodeNoReturn(TreeViewItem ParentNode);
        //ObservableCollection<Project> ;

        void ClearOneNode(int a);

        void populateChilds(int a);
        //ObservableCollection<>
        //ObservableCollection<>

    }
}
