﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FS_1
{
    /// <summary>
    /// Interaction logic for wpffeature.xaml
    /// </summary>
    public partial class wpffeature : UserControl
    {
        public wpffeature()
        {
            InitializeComponent();

            DataGridTextColumn c1 = new DataGridTextColumn();
            c1.Header = "Tool Use Case ID";
            c1.Binding = new Binding("name");


            dataGrid1.Columns.Add(c1);

            DataGridTextColumn c2 = new DataGridTextColumn();
            c2.Header = "Tool Use Case";
            c2.Binding = new Binding("textbox");
            dataGrid1.Columns.Add(c2);

            DataGridTextColumn c3 = new DataGridTextColumn();
            c3.Header = "Potential Malfunction or Erroneous Output";
            c3.Binding = new Binding("textbox1");
            dataGrid1.Columns.Add(c3);

            DataGridTextColumn c4 = new DataGridTextColumn();
            c4.Header = "Tool Impact(TI)";
            c4.Binding = new Binding("Name2");
            dataGrid1.Columns.Add(c4);

            DataGridTextColumn c5 = new DataGridTextColumn();
            c5.Header = "Reason For Selecting TI";
            c5.Binding = new Binding("Name3");
            dataGrid1.Columns.Add(c5);

            DataGridTextColumn c6 = new DataGridTextColumn();
            c6.Header = "Tool Error Detection";
            c6.Binding = new Binding("Name4");
            dataGrid1.Columns.Add(c6);

            DataGridTextColumn c7 = new DataGridTextColumn();
            c7.Header = "Reason For Selecting TD";
            c7.Binding = new Binding("Name5");
            dataGrid1.Columns.Add(c7);

            // var 

            dataGrid1.Items.Add(new Item() { name = "<Feature1>_01", textbox = "Usecase_Details", textbox1 = "Malfunction_Details", Name2 = "Tool Impact_Details", Name3 = "Reason for TI_Details", Name4 = "Tool Error Detection_Details", Name5 = "Reason for TD_Details" });
            // dataGrid1.Items.Add(new Item() { name = 2, Name = ""  });
            // dataGrid1.Items.Add(new Item() { name = 3, Name = ""  });
            // dataGrid1.Items.Add(new Item() { name = 4, Name = ""  });
            //dataGrid1.RowStyle.IsSealed = false;
        }

        public class Item
        {
            public string name { get; set; }
            public string textbox { get; set; }
            public string textbox1 { get; set; }
            public string Name2 { get; set; }
            public string Name3 { get; set; }
            public string Name4 { get; set; }
            public string Name5 { get; set; }
        }
    }
}
