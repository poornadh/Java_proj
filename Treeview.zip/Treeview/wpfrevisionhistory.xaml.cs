﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FS_1
{
    /// <summary>
    /// Interaction logic for wpfrevisionhistory.xaml
    /// </summary>
    public partial class wpfrevisionhistory : UserControl
    {
        public wpfrevisionhistory()
        {
            InitializeComponent();
            DataGridTextColumn c1 = new DataGridTextColumn();
            c1.Header = "Version No.";
            c1.Binding = new Binding("name");

            dataGrid1.Columns.Add(c1);

            DataGridTextColumn c2 = new DataGridTextColumn();
            c2.Header = "Date";
            c2.Binding = new Binding("textbox");
            dataGrid1.Columns.Add(c2);

            DataGridTextColumn c3 = new DataGridTextColumn();
            c3.Header = "Change Description";
            c3.Binding = new Binding("textbox1");
            dataGrid1.Columns.Add(c3);

            DataGridTextColumn c4 = new DataGridTextColumn();
            c4.Header = "Prepared By";
            c4.Binding = new Binding("textbox2");
            dataGrid1.Columns.Add(c4);

            DataGridTextColumn c5 = new DataGridTextColumn();
            c5.Header = "Approved By";
            c5.Binding = new Binding("textbox3");
            dataGrid1.Columns.Add(c5);

           

           

            dataGrid1.Items.Add(new Item() { name = "<Version>_01", textbox = "Date_Details", textbox1 = "Change Description_Details", textbox2 = "Prepared By_Details", textbox3 = "Approved By_Details" });
           
        }

        public class Item
        {
            public string name { get; set; }
            public string textbox { get; set; }
            public string textbox1 { get; set; }
            public string textbox2 { get; set; }
            public string textbox3 { get; set; }
        }
    }
}
