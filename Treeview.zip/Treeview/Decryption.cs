﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.IO;
using System.Text.RegularExpressions;
using System.Windows;

namespace FS_1
{
    public class Decryption
    {
        public string myfile;
        public string myfile1;

        public string Decrypted_text;
       
        
        public void Decrypter()
        {

           
            List<string> decryptedString = new List<string>();

            var rijAlg = NewRijndaelManaged();

            // Create a decrytor to perform the stream transform.
            System.Security.Cryptography.ICryptoTransform decryptor = rijAlg.CreateDecryptor(rijAlg.Key, rijAlg.IV);

         
                myfile = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), Global.filename);
                string[] lines = System.IO.File.ReadAllLines(myfile);
            
          
           // FileStream fs1 = new FileStream(myfile, FileMode.Open,FileAccess.Read);
            //int pos = 260;
            //fs1.Seek(pos, SeekOrigin.Begin);
            


            foreach (string cipherText in lines)
            {
                try
                {
                    //MessageBox.Show("1");
                    if (string.IsNullOrEmpty(cipherText))
                       throw new ArgumentNullException("cipherText");
                   
                    var cipher = Convert.FromBase64String(cipherText);
                    // Create the streams used for decryption.
                   
                    using (MemoryStream msDecrypt = new MemoryStream(cipher))
                    {
                        
                        using (CryptoStream csDecrypt = new CryptoStream(msDecrypt, decryptor, CryptoStreamMode.Read))
                        {
                            using (StreamReader srDecrypt = new StreamReader(csDecrypt))
                            {
                                decryptedString.Add(srDecrypt.ReadToEnd());
                               
                                // Read the decrypted bytes from the decrypting stream
                                // and place them in a string.
                            }
                        }
                    }
                }

                catch (Exception)
                {
                    MessageBox.Show("Error in decryption");
                    decryptedString.Add(cipherText);
                }
            }

           
           // MessageBox.Show("Decrypter");
            File.WriteAllLines(myfile, decryptedString.ToArray(), Encoding.UTF8);
            string text = decryptedString.ElementAt(0);
            //MessageBox.Show(text);
            Deserialize deserializer = new Deserialize();
            deserializer.Deserializer(decryptedString.ElementAt(0));
          // MessageBox.Show("Deserializer");
           // return text;
        }

       public Summary GetSummary(string text)
        {
            Deserialize deserializer = new Deserialize();
            Summary deserialized_string = (Summary)deserializer.Deserializer1(text);
          //  MessageBox.Show("Deserialzer");
            return deserialized_string;
        }

       public Tool_Details GetTool(string text)
        {
            Deserialize deserializer = new Deserialize();
             object o = deserializer.Deserializer2(text);
            if (o is Tool_Details deserialized_string)
            {
           //     MessageBox.Show("Deserialzer");
                return deserialized_string;
            }
            return null;
        }       

        public static bool IsBase64String(string base64String)
        {
            base64String = base64String.Trim();
            return (base64String.Length % 4 == 0) &&
            Regex.IsMatch(base64String, @"^[a-zA-Z0-9\+/]*={0,3}$", RegexOptions.None);

        }

        private static RijndaelManaged NewRijndaelManaged()
        {
            var saltBytes = Encoding.ASCII.GetBytes(FS_1.Properties.Resources.password);
            var key = new Rfc2898DeriveBytes(FS_1.Properties.Resources.InputKey, saltBytes);
            var aesAlg = new RijndaelManaged();
            aesAlg.Key = key.GetBytes(aesAlg.KeySize / 8);
            aesAlg.IV = key.GetBytes(aesAlg.BlockSize / 8);
            return aesAlg;
        }//End of NewRijndaelManaged
    }
}









