﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace FS_1
{
     public class Feature : CustomTreeViewItem
    {

        //List<UseCases> Use_Cases = new List<UseCases>(); //list of usecases

        public Feature()
        {
            UseCaseCollection = new ObservableCollection<UseCases>();
        }
        //public string header { get; set; }
        //public ObservableCollection<UseCases> InstanceUsecase { get; set; }
        private ObservableCollection<UseCases> _useCaseCollection;
        public ObservableCollection<UseCases> UseCaseCollection
        {
            get => _useCaseCollection;
            set
            {
                if (_useCaseCollection != value)
                {
                    _useCaseCollection = value;
                    OnPropertyChanged("UseCaseCollection");
                }
            }
        }

        public void AddFeature(TreeViewItem ParentNode)
        {
            //ParentNode.Items.Add(childeNode);
            TreeViewItem AddFeatureToTool = new TreeViewItem { Header = "Tool_Name", Uid =""};
            ParentNode.Items.Add(AddFeatureToTool);
        }

        public UseCases AddUseCase()
        {
            UseCases InstanceOfUseCase = new UseCases();
            UseCaseCollection.Add(new UseCases() { Header = "Use Case 0", Uid = ""});
            //TreeViewItem AddUseCaseToFeature = new TreeViewItem { Header = ToAddUseCase.TCLUseCase, Uid = "" };
            //ParentNode.Items.Add(AddUseCaseToFeature);
            return InstanceOfUseCase;
        }
    }
}
