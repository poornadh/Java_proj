﻿using Newtonsoft.Json;
using System.Collections.Generic;
using System;
using System.Windows;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.IO;
namespace FS_1
{
    public class Deserialize
    {
        public void Deserializer(string text)
        {

            Project ValueList = JsonConvert.DeserializeObject<Project>(text);
        }



        //Function for deserializing Summary
        public Summary Deserializer1(string text)
        {

            Summary deserialized_string = JsonConvert.DeserializeObject<Summary>(text);

            return deserialized_string;

        }
        //Function for deserializing Tool details
        public Tool_Details Deserializer2(string text)
        {

            Tool_Details deserialized_string = JsonConvert.DeserializeObject<Tool_Details>(text);

            return deserialized_string;

        }


    }
       
    
}

