﻿namespace FS_1
{
    partial class FeatureWithUsecase
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.components = new System.ComponentModel.Container();
            System.Windows.Forms.TreeNode treeNode1 = new System.Windows.Forms.TreeNode("Usecase1");
            System.Windows.Forms.TreeNode treeNode2 = new System.Windows.Forms.TreeNode("Usecase2");
            System.Windows.Forms.TreeNode treeNode3 = new System.Windows.Forms.TreeNode("Usecase3");
            System.Windows.Forms.TreeNode treeNode4 = new System.Windows.Forms.TreeNode("Feature1", new System.Windows.Forms.TreeNode[] {
            treeNode1,
            treeNode2,
            treeNode3});
            System.Windows.Forms.TreeNode treeNode5 = new System.Windows.Forms.TreeNode("Usecase4");
            System.Windows.Forms.TreeNode treeNode6 = new System.Windows.Forms.TreeNode("Usecase5");
            System.Windows.Forms.TreeNode treeNode7 = new System.Windows.Forms.TreeNode("Usecase6");
            System.Windows.Forms.TreeNode treeNode8 = new System.Windows.Forms.TreeNode("Feature2", new System.Windows.Forms.TreeNode[] {
            treeNode5,
            treeNode6,
            treeNode7});
            System.Windows.Forms.TreeNode treeNode9 = new System.Windows.Forms.TreeNode("Features", new System.Windows.Forms.TreeNode[] {
            treeNode4,
            treeNode8});
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(FeatureWithUsecase));
            this.panel1 = new System.Windows.Forms.Panel();
            this.panel6 = new System.Windows.Forms.Panel();
            this.toolStrip1 = new System.Windows.Forms.ToolStrip();
            this.Add_Button = new System.Windows.Forms.ToolStripButton();
            this.Delete_button = new System.Windows.Forms.ToolStripButton();
            this.toolStripSeparator1 = new System.Windows.Forms.ToolStripSeparator();
            this.searchbox = new System.Windows.Forms.ToolStripTextBox();
            this.Search_button = new System.Windows.Forms.ToolStripButton();
            this.button2 = new System.Windows.Forms.Button();
            this.button1 = new System.Windows.Forms.Button();
            this.panel3 = new System.Windows.Forms.Panel();
            this.panel5 = new System.Windows.Forms.Panel();
            this.Treeform = new System.Windows.Forms.TreeView();
            this.panel4 = new System.Windows.Forms.Panel();
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.UseCase_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tool_Usecase = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Malfunction_output = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tool_Impact = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Reasons_TI = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tool_Detection = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Reasons_TD = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TCL_Malfunction_output = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TCL_usecase = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.TCL_For_TCL2_TCL3 = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.weightage_usecase = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.normalized_weightage_TCL = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.remarks = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.panel2 = new System.Windows.Forms.Panel();
            this.FeatLabel = new System.Windows.Forms.Label();
            this.errorProvider1 = new System.Windows.Forms.ErrorProvider(this.components);
            this.panel1.SuspendLayout();
            this.panel6.SuspendLayout();
            this.toolStrip1.SuspendLayout();
            this.panel3.SuspendLayout();
            this.panel5.SuspendLayout();
            this.panel4.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).BeginInit();
            this.SuspendLayout();
            // 
            // panel1
            // 
            this.panel1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel1.BackColor = System.Drawing.SystemColors.GradientInactiveCaption;
            this.panel1.Controls.Add(this.panel6);
            this.panel1.Controls.Add(this.button2);
            this.panel1.Controls.Add(this.button1);
            this.panel1.Controls.Add(this.panel3);
            this.panel1.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.panel1.Location = new System.Drawing.Point(-2, 1);
            this.panel1.Name = "panel1";
            this.panel1.Size = new System.Drawing.Size(1287, 688);
            this.panel1.TabIndex = 0;
            // 
            // panel6
            // 
            this.panel6.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel6.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel6.Controls.Add(this.toolStrip1);
            this.panel6.Location = new System.Drawing.Point(3, 38);
            this.panel6.Name = "panel6";
            this.panel6.Size = new System.Drawing.Size(1281, 28);
            this.panel6.TabIndex = 3;
            // 
            // toolStrip1
            // 
            this.toolStrip1.Items.AddRange(new System.Windows.Forms.ToolStripItem[] {
            this.Add_Button,
            this.Delete_button,
            this.toolStripSeparator1,
            this.searchbox,
            this.Search_button});
            this.toolStrip1.Location = new System.Drawing.Point(0, 0);
            this.toolStrip1.Name = "toolStrip1";
            this.toolStrip1.Size = new System.Drawing.Size(1281, 25);
            this.toolStrip1.TabIndex = 0;
            this.toolStrip1.Text = "toolStrip1";
            // 
            // Add_Button
            // 
            this.Add_Button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Add_Button.Image = global::FS_1.Properties.Resources.add;
            this.Add_Button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Add_Button.Name = "Add_Button";
            this.Add_Button.Size = new System.Drawing.Size(23, 22);
            this.Add_Button.Text = "toolStripButton1";
            this.Add_Button.ToolTipText = "Add";
            this.Add_Button.Click += new System.EventHandler(this.Add_Button_Click);
            // 
            // Delete_button
            // 
            this.Delete_button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Delete_button.Image = global::FS_1.Properties.Resources.delete;
            this.Delete_button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Delete_button.Name = "Delete_button";
            this.Delete_button.Size = new System.Drawing.Size(23, 22);
            this.Delete_button.ToolTipText = "Delete";
            this.Delete_button.Click += new System.EventHandler(this.Delete_button_Click);
            // 
            // toolStripSeparator1
            // 
            this.toolStripSeparator1.Name = "toolStripSeparator1";
            this.toolStripSeparator1.Size = new System.Drawing.Size(6, 25);
            // 
            // searchbox
            // 
            this.searchbox.Name = "searchbox";
            this.searchbox.Size = new System.Drawing.Size(100, 25);
            this.searchbox.TextChanged += new System.EventHandler(this.searchbox_TextChanged);
            // 
            // Search_button
            // 
            this.Search_button.DisplayStyle = System.Windows.Forms.ToolStripItemDisplayStyle.Image;
            this.Search_button.Image = global::FS_1.Properties.Resources.search;
            this.Search_button.ImageTransparentColor = System.Drawing.Color.Magenta;
            this.Search_button.Name = "Search_button";
            this.Search_button.Size = new System.Drawing.Size(23, 22);
            this.Search_button.Text = "toolStripButton3";
            this.Search_button.ToolTipText = "Search";
            this.Search_button.Click += new System.EventHandler(this.Search_button_Click);
            // 
            // button2
            // 
            this.button2.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button2.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button2.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.button2.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button2.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button2.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button2.Location = new System.Drawing.Point(1093, 651);
            this.button2.Name = "button2";
            this.button2.Size = new System.Drawing.Size(75, 23);
            this.button2.TabIndex = 2;
            this.button2.Text = "Save";
            this.button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            this.button1.Anchor = ((System.Windows.Forms.AnchorStyles)((System.Windows.Forms.AnchorStyles.Bottom | System.Windows.Forms.AnchorStyles.Right)));
            this.button1.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.button1.FlatAppearance.BorderColor = System.Drawing.Color.Gray;
            this.button1.FlatAppearance.MouseDownBackColor = System.Drawing.Color.Silver;
            this.button1.FlatAppearance.MouseOverBackColor = System.Drawing.Color.FromArgb(((int)(((byte)(224)))), ((int)(((byte)(224)))), ((int)(((byte)(224)))));
            this.button1.FlatStyle = System.Windows.Forms.FlatStyle.Flat;
            this.button1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.button1.Location = new System.Drawing.Point(1189, 651);
            this.button1.Name = "button1";
            this.button1.Size = new System.Drawing.Size(75, 23);
            this.button1.TabIndex = 1;
            this.button1.Text = "Cancel";
            this.button1.UseVisualStyleBackColor = false;
            this.button1.Click += new System.EventHandler(this.button1_Click);
            // 
            // panel3
            // 
            this.panel3.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel3.Controls.Add(this.panel5);
            this.panel3.Controls.Add(this.panel4);
            this.panel3.Location = new System.Drawing.Point(1, 70);
            this.panel3.Name = "panel3";
            this.panel3.Size = new System.Drawing.Size(1285, 570);
            this.panel3.TabIndex = 0;
            // 
            // panel5
            // 
            this.panel5.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left)));
            this.panel5.Controls.Add(this.Treeform);
            this.panel5.Location = new System.Drawing.Point(3, 3);
            this.panel5.Name = "panel5";
            this.panel5.Size = new System.Drawing.Size(191, 567);
            this.panel5.TabIndex = 1;
            // 
            // Treeform
            // 
            this.Treeform.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.Treeform.Font = new System.Drawing.Font("Calibri", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Treeform.Location = new System.Drawing.Point(0, 0);
            this.Treeform.Name = "Treeform";
            treeNode1.Name = "Node3";
            treeNode1.Text = "Usecase1";
            treeNode2.Name = "Node4";
            treeNode2.Text = "Usecase2";
            treeNode3.Name = "Node5";
            treeNode3.Text = "Usecase3";
            treeNode4.Name = "Node1";
            treeNode4.Text = "Feature1";
            treeNode5.Name = "Node6";
            treeNode5.Text = "Usecase4";
            treeNode6.Name = "Node7";
            treeNode6.Text = "Usecase5";
            treeNode7.Name = "Node8";
            treeNode7.Text = "Usecase6";
            treeNode8.Name = "Node2";
            treeNode8.Text = "Feature2";
            treeNode9.Name = "Node0";
            treeNode9.Text = "Features";
            treeNode9.ToolTipText = "Contains Feature List";
            this.Treeform.Nodes.AddRange(new System.Windows.Forms.TreeNode[] {
            treeNode9});
            this.Treeform.Size = new System.Drawing.Size(191, 567);
            this.Treeform.TabIndex = 0;
            this.Treeform.AfterSelect += new System.Windows.Forms.TreeViewEventHandler(this.Treeform_AfterSelect);
            // 
            // panel4
            // 
            this.panel4.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel4.Controls.Add(this.dataGridView1);
            this.panel4.Location = new System.Drawing.Point(200, 0);
            this.panel4.Name = "panel4";
            this.panel4.Size = new System.Drawing.Size(1082, 570);
            this.panel4.TabIndex = 0;
            // 
            // dataGridView1
            // 
            this.dataGridView1.AllowUserToAddRows = false;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Calibri", 9F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.dataGridView1.AlternatingRowsDefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridView1.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridView1.BackgroundColor = System.Drawing.SystemColors.GradientInactiveCaption;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleLeft;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.InactiveBorder;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Segoe UI Semibold", 9.75F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.WindowText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.SystemColors.ActiveCaption;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.HighlightText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.True;
            this.dataGridView1.ColumnHeadersDefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.UseCase_ID,
            this.Tool_Usecase,
            this.Malfunction_output,
            this.Tool_Impact,
            this.Reasons_TI,
            this.Tool_Detection,
            this.Reasons_TD,
            this.TCL_Malfunction_output,
            this.TCL_usecase,
            this.TCL_For_TCL2_TCL3,
            this.weightage_usecase,
            this.normalized_weightage_TCL,
            this.remarks});
            this.dataGridView1.Cursor = System.Windows.Forms.Cursors.Arrow;
            this.dataGridView1.GridColor = System.Drawing.SystemColors.ControlLightLight;
            this.dataGridView1.Location = new System.Drawing.Point(0, 2);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(1082, 568);
            this.dataGridView1.TabIndex = 0;
            this.dataGridView1.RowPrePaint += new System.Windows.Forms.DataGridViewRowPrePaintEventHandler(this.dataGridView1_RowPrePaint);
            // 
            // UseCase_ID
            // 
            this.UseCase_ID.HeaderText = "Tool Use Case ID";
            this.UseCase_ID.Name = "UseCase_ID";
            // 
            // Tool_Usecase
            // 
            this.Tool_Usecase.HeaderText = "Tool Use Case";
            this.Tool_Usecase.Name = "Tool_Usecase";
            // 
            // Malfunction_output
            // 
            this.Malfunction_output.HeaderText = "Potential Malfunction or Erroneous Output";
            this.Malfunction_output.Name = "Malfunction_output";
            // 
            // Tool_Impact
            // 
            this.Tool_Impact.HeaderText = "Tool Impact (TI)";
            this.Tool_Impact.Name = "Tool_Impact";
            // 
            // Reasons_TI
            // 
            this.Reasons_TI.HeaderText = "Reasons for Selecting TI";
            this.Reasons_TI.Name = "Reasons_TI";
            // 
            // Tool_Detection
            // 
            this.Tool_Detection.HeaderText = "Tool Error Detection";
            this.Tool_Detection.Name = "Tool_Detection";
            // 
            // Reasons_TD
            // 
            this.Reasons_TD.HeaderText = "Reasons for Selecting TD";
            this.Reasons_TD.Name = "Reasons_TD";
            // 
            // TCL_Malfunction_output
            // 
            this.TCL_Malfunction_output.HeaderText = "Tool Confidence Level (TCL) (for Potential Malfunction / Erroneous Output)";
            this.TCL_Malfunction_output.Name = "TCL_Malfunction_output";
            // 
            // TCL_usecase
            // 
            this.TCL_usecase.HeaderText = "Tool Confidence Level (TCL) (for the Use Case)";
            this.TCL_usecase.Name = "TCL_usecase";
            // 
            // TCL_For_TCL2_TCL3
            // 
            this.TCL_For_TCL2_TCL3.HeaderText = "Tool Confidence Level TCL2 or TCL3";
            this.TCL_For_TCL2_TCL3.Name = "TCL_For_TCL2_TCL3";
            // 
            // weightage_usecase
            // 
            this.weightage_usecase.HeaderText = "Weightage for this Use Case";
            this.weightage_usecase.Name = "weightage_usecase";
            // 
            // normalized_weightage_TCL
            // 
            this.normalized_weightage_TCL.HeaderText = "Normalized Weightage for TCL";
            this.normalized_weightage_TCL.Name = "normalized_weightage_TCL";
            // 
            // remarks
            // 
            this.remarks.HeaderText = "Remarks";
            this.remarks.Name = "remarks";
            // 
            // panel2
            // 
            this.panel2.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.panel2.BackColor = System.Drawing.SystemColors.ActiveCaption;
            this.panel2.Controls.Add(this.FeatLabel);
            this.panel2.Location = new System.Drawing.Point(0, 0);
            this.panel2.Name = "panel2";
            this.panel2.Size = new System.Drawing.Size(1284, 38);
            this.panel2.TabIndex = 1;
            // 
            // FeatLabel
            // 
            this.FeatLabel.AutoSize = true;
            this.FeatLabel.Font = new System.Drawing.Font("Calibri", 14.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.FeatLabel.Location = new System.Drawing.Point(12, 9);
            this.FeatLabel.Name = "FeatLabel";
            this.FeatLabel.Size = new System.Drawing.Size(126, 23);
            this.FeatLabel.TabIndex = 0;
            this.FeatLabel.Text = "Feature  Sheet";
            // 
            // errorProvider1
            // 
            this.errorProvider1.ContainerControl = this;
            // 
            // FeatureWithUsecase
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(1284, 687);
            this.Controls.Add(this.panel2);
            this.Controls.Add(this.panel1);
            this.Font = new System.Drawing.Font("Calibri", 8.25F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(0)));
            this.Icon = ((System.Drawing.Icon)(resources.GetObject("$this.Icon")));
            this.MinimumSize = new System.Drawing.Size(1200, 726);
            this.Name = "FeatureWithUsecase";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "Functional Safety";
            this.WindowState = System.Windows.Forms.FormWindowState.Maximized;
            this.panel1.ResumeLayout(false);
            this.panel6.ResumeLayout(false);
            this.panel6.PerformLayout();
            this.toolStrip1.ResumeLayout(false);
            this.toolStrip1.PerformLayout();
            this.panel3.ResumeLayout(false);
            this.panel5.ResumeLayout(false);
            this.panel4.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.panel2.ResumeLayout(false);
            this.panel2.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)(this.errorProvider1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.Panel panel1;
        private System.Windows.Forms.Button button2;
        private System.Windows.Forms.Button button1;
        private System.Windows.Forms.Panel panel3;
        private System.Windows.Forms.Panel panel5;
        private System.Windows.Forms.Panel panel4;
        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.Panel panel2;
        private System.Windows.Forms.Label FeatLabel;
        private System.Windows.Forms.DataGridViewTextBoxColumn UseCase_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tool_Usecase;
        private System.Windows.Forms.DataGridViewTextBoxColumn Malfunction_output;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tool_Impact;
        private System.Windows.Forms.DataGridViewTextBoxColumn Reasons_TI;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tool_Detection;
        private System.Windows.Forms.DataGridViewTextBoxColumn Reasons_TD;
        private System.Windows.Forms.DataGridViewTextBoxColumn TCL_Malfunction_output;
        private System.Windows.Forms.DataGridViewTextBoxColumn TCL_usecase;
        private System.Windows.Forms.DataGridViewTextBoxColumn TCL_For_TCL2_TCL3;
        private System.Windows.Forms.DataGridViewTextBoxColumn weightage_usecase;
        private System.Windows.Forms.DataGridViewTextBoxColumn normalized_weightage_TCL;
        private System.Windows.Forms.DataGridViewTextBoxColumn remarks;
        public System.Windows.Forms.TreeView Treeform;
        private System.Windows.Forms.Panel panel6;
        private System.Windows.Forms.ToolStrip toolStrip1;
        private System.Windows.Forms.ToolStripButton Add_Button;
        private System.Windows.Forms.ToolStripButton Delete_button;
        private System.Windows.Forms.ToolStripSeparator toolStripSeparator1;
        private System.Windows.Forms.ToolStripTextBox searchbox;
        private System.Windows.Forms.ToolStripButton Search_button;
        private System.Windows.Forms.ErrorProvider errorProvider1;
    }
}