﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Windows.Controls;

namespace FS_1
{
    public class Functional_Safety : CustomTreeViewItem
    {
        public new string Header { get; set; }
        NewProject project = new NewProject();

        private ObservableCollection<Project> _projectCollection;
        public ObservableCollection<Project> ProjectCollection
        {
            get { return _projectCollection; }
            set
            {
                if (_projectCollection != value)
                    _projectCollection = value;
                OnPropertyChanged("ProjectCollection");
            }
            
        }
        public Functional_Safety()
        {
            //System.Windows.MessageBox.Show("Entering!!!!");
            //ProjectCollection = GetProjectCollection();
            //return ProjectCollection;
            ProjectCollection = new ObservableCollection<Project>();
        }

        public ObservableCollection<Project> GetFS()
        {
            ProjectCollection = GetProjectCollection();
            return ProjectCollection;
        }
        ObservableCollection<Sheets> GetSheetsCollection()
        {
           // ObservableCollection<Sheets> SheetsList = new ObservableCollection<Sheets>();
            Sheets InsSheets = new Sheets();
            InsSheets.Ins_Tool.SheetsCollection = new ObservableCollection<Sheets>();
            InsSheets.Ins_Tool.SheetsCollection.Add(new Sheets() { Header = InsSheets.SummaryObjects.Header , UId=InsSheets.SummaryObjects.Header+InsSheets.Ins_Tool.SheetsCollection.Count});
            InsSheets.Ins_Tool.SheetsCollection.Add(new Sheets() { Header = InsSheets.RevisionHistoryObjects.Header, UId=InsSheets.RevisionHistoryObjects.Header+ InsSheets.Ins_Tool.SheetsCollection.Count});
            InsSheets.Ins_Tool.SheetsCollection.Add(new Sheets() { Header = InsSheets.AnalysisSummaryObjects.Header, UId = InsSheets.AnalysisSummaryObjects.Header + InsSheets.Ins_Tool.SheetsCollection.Count});
            InsSheets.Ins_Tool.SheetsCollection.Add(new Sheets() { Header = InsSheets.ToolDetailsObjects.Header, UId = InsSheets.ToolDetailsObjects.Header + InsSheets.Ins_Tool.SheetsCollection.Count });
            InsSheets.Ins_Tool.SheetsCollection.Add(new Sheets() { Header = InsSheets.FeatureObjects.Header, UId = InsSheets.FeatureObjects.Header + InsSheets.Ins_Tool.SheetsCollection.Count });
            //SheetsList.Add(new Sheets() { Header = InsSheets.SummaryObjects.Header });
            //SheetsList.Add(new Sheets() { Header = InsSheets.RevisionHistoryObjects.Header });
            //SheetsList.Add(new Sheets() { Header = InsSheets.AnalysisSummaryObjects.Header });
            //SheetsList.Add(new Sheets() { Header = InsSheets.ToolDetailsObjects.Header });
            //SheetsList.Add(new Sheets() { Header = InsSheets.FeatureObjects.Header });
            return InsSheets.Ins_Tool.SheetsCollection;
        }

        ObservableCollection<Tool> GetToolcollection()
        {
            ObservableCollection<Sheets> InsSheetsCollection = GetSheetsCollection();
            // System.Windows.MessageBox.Show("The sheets collection has : " + InsSheetsCollection.Count);
            Selectactivity InstanceSA = new Selectactivity();
            InstanceSA.ToolsCollection = new ObservableCollection<Tool>();
            InstanceSA.ToolsCollection.Add(new Tool() { Header = "RTE TCG", ToolName = "RTE TCG", SheetsCollection = InsSheetsCollection });
           // InstanceSA.ToolsCollection.Add(new Tool() {Header = "RTE Code Generator", ToolName = "RTE CG", SheetsCollection = InsSheetsCollection});
            
            return InstanceSA.ToolsCollection;
        }

        ObservableCollection<Selectactivity> GetSelectactivitiesCollection()
        {
           // ObservableCollection<Sheets> InsSheetsCollection = GetSheetsCollection();
            ObservableCollection<Tool> InsToolCollection = GetToolcollection();
            Project InstanceProject = new Project();
            InstanceProject.ActivityCollection = new ObservableCollection<Selectactivity>();
            InstanceProject.ActivityCollection.Add(new Selectactivity() { Header = "TCL", ToolsCollection = InsToolCollection});
               
            return InstanceProject.ActivityCollection;
        }

        public ObservableCollection<Project> GetProjectCollection()
        {
            //ObservableCollection<Sheets> InsSheetsCollection = GetSheetsCollection();
            //ObservableCollection<Tool> InsToolCollection = GetToolcollection();
            ObservableCollection<Selectactivity> InsSelectActivitiesCollection = GetSelectactivitiesCollection();
            //ProjectCollection = new ObservableCollection<Project>();
            ProjectCollection.Add(new Project() { Header = Global.filename_without_extension, ActivityCollection = InsSelectActivitiesCollection });
            return ProjectCollection;
        }
    }

}      

