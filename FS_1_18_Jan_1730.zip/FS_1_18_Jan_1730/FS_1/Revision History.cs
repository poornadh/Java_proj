﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FS_1
{
    public partial class Revision_History : Form
    {
        public Revision_History()
        {
            InitializeComponent();
            dataGridView1.Rows.Add();
        }

        private void dataGridView1_CellContentClick(object sender, DataGridViewCellEventArgs e)
        {

        }
       
        //Giving Header Value to Each Row

        private void dataGridView1_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            String dgvheader = String.Format("{0}", e.RowIndex + 1);

            if (dataGridView1.Rows[e.RowIndex].HeaderCell.Value == null || dgvheader != dataGridView1.Rows[e.RowIndex].HeaderCell.Value.ToString())
            {
                dataGridView1.Rows[e.RowIndex].HeaderCell.Value = dgvheader;
            }
        }
        
        //Ok the Form
        private void Ok_Click(object sender, EventArgs e)
        {

        }
        
        //To Close The Form

        private void Cancel_Click(object sender, EventArgs e)
        {
            this.Close();
        }

       

       //To search a String


        private void search_Click(object sender, EventArgs e)
        {
            string str = searchbox.Text;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                bool valueResult = false;
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    for (int i = 0; i < row.Cells.Count; i++)
                    {
                        if (row.Cells[i].Value != null && row.Cells[i].Value.ToString().Contains(str))
                        {
                            int rowIndex = row.Index;
                            dataGridView1.Rows[rowIndex].Selected = true;
                            valueResult = true;
                            errorProvider1.Clear();
                            break;
                        }
                    }

                }
                if (!valueResult)
                {
                    errorProvider1.SetError(error_Label,"Unable to Find Your Search");
                    return;
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }


        //If SearchBox Text Changed

        private void searchbox_TextChanged_1(object sender, EventArgs e)
        {
            errorProvider1.Clear();
        }

        //Delete Selected Rows

        private void delete_row_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow dg in dataGridView1.SelectedRows)
            {
                
                dataGridView1.Rows.RemoveAt(dg.Index);
            }
        }
        

        //Add New Row to Table
        private void Add_row_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add();
        }
    }
}
