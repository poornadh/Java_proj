﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using FS_1.Models;

namespace FS_1
{
    public class SummaryViewModel: CustomTreeViewItem
    {
        private Summary _summary;

        public Summary Summary
        {
            get { return _summary; }
            set
            {
                _summary = value;
                OnPropertyChanged("Summary");
            }
        }

        //private string _projectName;
        public string ProjectName
        {
            get { return Summary.ProjectName; }
            set
            {
                Summary.ProjectName = value;
                OnPropertyChanged("ProjectName");
            }
        }

        //private string _customerName;
        public string CustomerName
        {
            get { return Summary.CustomerName; }
            set
            {
                Summary.CustomerName = value;
                OnPropertyChanged("CustomerName");
            }
        }

        //private string _projectManager;
        public string ProjectManager
        {
            get { return Summary.ProjectManager; }
            set
            {
                Summary.ProjectManager = value;
                OnPropertyChanged("ProjectManager");
            }
        }

        //private string _toolName;
        public string ToolName
        {
            get { return Summary.ToolName; }
            set
            {
                Summary.ToolName = value;
                OnPropertyChanged("ToolName");
            }
        }

        //private string _toolVersionNo;
        public string ToolVersionNo
        {
            get { return Summary.ToolVersionNo; }
            set
            {
                Summary.ToolVersionNo = value;
                OnPropertyChanged("ToolVersionNo");
            }
        }

        //private string _documentId;
        public string DocumentId
        {
            get { return Summary.DocumentId; }
            set
            {
                Summary.DocumentId = value;
                OnPropertyChanged("DocumentId");
            }
        }

        //private string _documentVersionNo;
        public string DocumentVersionNo
        {
            get { return Summary.DocumentVersionNo; }
            set
            {
                Summary.DocumentVersionNo = value;
                OnPropertyChanged("DocumentVersionNo");
            }
        }

        //private string _date;
        public string Date
        {
            get { return Summary.Date; }
            set
            {
                Summary.Date = value;
                OnPropertyChanged("Date");
            }
        }

        //private string _documentOverview;
        public string DocumentOverview
        {
            get { return Summary.DocumentOverview; }
            set
            {
                Summary.DocumentOverview = value;
                OnPropertyChanged("DocumentOverview");
            }
        }
        /*  TreeViewItem AddSummaryToTool;
         public string ProjectName { get; set; }
         public string CustomerName { get; set; }
         public string ProjectManager { get; set; }
         public string ToolName { get; set; }
         public string ToolVersionNo { get; set; }
         public string DocumentId { get; set; }
         public string DocumentVersionNo { get; set; }
         public string Date { get; set; }
         public string DocumentOverview { get; set; }*/

        //public void AddSummary(Tool ParentNode)
        //{
        //    AddSummaryToTool = new TreeViewItem { Header = "Summary", UId =""};
        //    ParentNode.Items.Add(AddSummaryToTool);
        //}
    }
}
