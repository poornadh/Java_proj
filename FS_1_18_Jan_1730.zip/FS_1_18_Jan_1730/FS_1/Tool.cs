﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Windows.Forms;
using System.Windows.Controls;

namespace FS_1
{
    public class Tool : CustomTreeViewItem
    {
        //public ObservableCollection<Details> items;

        public Tool()
        {
            SheetsCollection = new ObservableCollection<Sheets>();
            FeaturesCollection = new ObservableCollection<Feature>();
        }

        public string ToolName { get; set; }
        private ObservableCollection<Sheets> _sheetsCollection;
        public ObservableCollection<Sheets> SheetsCollection
        {
            get { return _sheetsCollection; }
            set
            {
                if (_sheetsCollection != value)
                {
                    _sheetsCollection = value;
                    OnPropertyChanged("SheetsCollection");
                }
            }
        }
        
         
        private ObservableCollection<Feature> _featuresCollection;
        public ObservableCollection<Feature> FeaturesCollection
        {
            get => _featuresCollection;
            set
            {
                if (_featuresCollection != value)
                {
                    _featuresCollection = value;
                    OnPropertyChanged("FeaturesCollection");
                }
            }
        }

        public TreeViewItem AddTool(TreeViewItem ParentNode)
        {
            TreeViewItem AddToolToSA = new TreeViewItem { Header = "Tool_Name", Uid = "" };
            ParentNode.Items.Add(AddToolToSA);
            return AddToolToSA;
        }
    }
}
