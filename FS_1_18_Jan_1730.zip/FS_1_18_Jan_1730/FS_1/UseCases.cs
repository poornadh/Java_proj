﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;
using System.Windows.Forms;

namespace FS_1
{
            public class UseCases: CustomTreeViewItem
            {
                //Malfunctions childeNode;
                //ObservableCollection<Malfunctions> Mal_functions = new ObservableCollection<Malfunctions>(); //list of malfunctions
                private ObservableCollection<Malfunctions> _malfunctions;
                public ObservableCollection<Malfunctions> MalfunctionsCollection
                {
                    //equivalent to get {return _malfunctions}
                    get => _malfunctions;
                    set
                    {
                        if (_malfunctions != value)
                        {
                            _malfunctions = value;
                            OnPropertyChanged("MalfunctionsCollection");
                        }
                    }
                }



      
        
                private string _tCLUseCase;
                public string TCLUseCase
                {
                    get { return _tCLUseCase; }
                    set
                    {
                        if (_tCLUseCase != value)
                            _tCLUseCase = value;
                        OnPropertyChanged("TCLUseCase");
                    }
                }
                private string _tCL2orTCL3;
                public string TCL2orTCL3
                {
                    get { return _tCL2orTCL3; }
                    set
                    {
                        if (_tCL2orTCL3 != value)
                            _tCL2orTCL3 = value;
                        OnPropertyChanged("TCL2orTCL3");
                    }
                }
                private string _weightage;
                public string Weightage
                {
                    get { return _weightage; }
                    set
                    {
                        if (_weightage != value)
                            _weightage = value;
                        OnPropertyChanged("Weightage");
                    }
                }

                private string _normalizedWeightage;
                public string NormalizedWeightage
                {
                    get { return _normalizedWeightage; }
                    set
                    {
                        if (_normalizedWeightage != value)
                            _normalizedWeightage = value;
                        OnPropertyChanged("NormalizedWeightage");
                    }
                }
                private string _remarks;
                public string Remarks
                {
                    get { return _remarks; }
                    set
                    {
                        if (_remarks != value)
                            _remarks = value;
                        OnPropertyChanged("Remarks");
                    }
                }
       
                //public string Header { get; internal set; }
                //public string Uid { get; internal set; }

                public void AddMalfunc()
                {
                    //TBD : Add Malfunction for datagrid
                    //this.childeNode = new Malfunctions();
                }

                public void NumberOfUseCase()
                {
                    //Get Number Of Use Case here 

                }
            }
}
