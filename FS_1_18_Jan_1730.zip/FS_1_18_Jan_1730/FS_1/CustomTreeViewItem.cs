﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.ComponentModel;
using System.Linq;
using System.Linq.Expressions;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace FS_1
{
    public class CustomTreeViewItem: INotifyPropertyChanged
    {
        public CustomTreeViewItem()
        {
            //this.Members = new ObservableCollection<CustomTreeViewItem>();
        }
        public int index { get; set; }
        public string otherData { get; set; }
        public int id { get; set; }
        public int level { get; set; }
        public int next { get; set; }


        private string _header;
        public string Header
        {
            get { return _header; }
            set
            {
                if (_header != value)
                    _header = value;
                OnPropertyChanged("Header");
            }
        }

        public String UId
        {
            get;
            set;

        }
        public String Name { get; set; }
        // public ObservableCollection<CustomTreeViewItem> Members { get; set; } 


        #region Events

        public event PropertyChangedEventHandler PropertyChanged;

        #endregion

        #region Event Handlers

        /// <summary>
        /// Get name of property
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="e"></param>
        /// <returns></returns>
        public static string GetPropertyName<T>(Expression<Func<T>> e)
        {
            var member = (MemberExpression)e.Body;
            return member.Member.Name;
        }
        /// <summary>
        /// Raise when property value propertychanged or override propertychage
        /// </summary>
        /// <typeparam name="T"></typeparam>
        /// <param name="propertyExpression"></param>
        protected virtual void RaisePropertyChanged<T>
            (Expression<Func<T>> propertyExpression)
        {
            OnPropertyChanged(GetPropertyName(propertyExpression));
        }
        /// <summary>
        /// Raise when property value propertychanged
        /// </summary>
        /// <param name="propertyName"></param>
        protected void OnPropertyChanged(String propertyName)
        {
            PropertyChanged?.Invoke(this, new PropertyChangedEventArgs(propertyName));
            //PropertyChangedEventHandler temp = PropertyChanged;
            //temp?.Invoke(this, new PropertyChangedEventArgs(propertyName));
        }

        #endregion    
    }
}
