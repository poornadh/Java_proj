﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace FS_1
{
    public class Analysis_Summary : CustomTreeViewItem
    {
        public String TCLLevel; 
        public void AddAS(TreeViewItem ParentNode)
        {
            TreeViewItem AddASToTool = new TreeViewItem { Header = "Tool_Name", Uid =""};
            ParentNode.Items.Add(AddASToTool);
        }

    }
}
