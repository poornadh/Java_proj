﻿using System;
//using Excel = Microsoft.Office.Interop.Excel;

namespace FS_1
{
    public class Generate_Excel
    {
        public void Generate_ExcelSheet()
        {
            string[] SheeetNames = new string[] { "Summary", "Tool Details" };
            string[] SearchItems = null;
            string[] Values = null;
           // Excel.Application xlApp = new Excel.Application();
            //Excel.Workbook xlWorkbook = xlApp.Workbooks.Open(@"E:\Tool Automation Rework\Tool_Input\Copy of ShortProjectName_ToolName_TCL_Analysis - Copy.xlsx");
           
            //itterate through all the sheets 
            for (int k = 0; k < SheeetNames.Length; k++)
            {
               
                if (SheeetNames[k] == "Summary")
                {
                    SearchItems = new string[] { "Project Name", "Customer Name", "Project Manager", "Tool Name", "Tool Version No", "Document ID", "Document Version No", "Date", "Document Overview" };
                    Values = new string[] { Global.summary.ProjectName, Global.summary.CustomerName, Global.summary.ProjectManager, Global.summary.ToolName, Global.summary.ToolVersionNo, Global.summary.DocumentId, Global.summary.DocumentVersionNo, Global.summary.Date, Global.summary.DocumentOverview };
                    common_func("Summary");
                }
                if (SheeetNames[k] == "Tool Details")
                {
                    SearchItems = new string[] { "Name", "Name of Vendor and Address", "Version No.", "Usage Environment", "Purchase Date", "Installation Date", "Is the tool under warranty or Annual Maintenance Contract? If yes, provide details and expiry date of  warranty/AMC.", "Purpose", "Project Inputs", "User Manuals", "Test Reports","ASIL of the Target Application to be developed using this tool"};
                    Values = new string[] { Global.details.ToolName, Global.details.VendorName, Global.details.VersionNo, Global.details.UsageEnvironment, Global.details.PurchaseDate, Global.details.InstallationDate, Global.details.MaintenanceContract, Global.details.Purpose, Global.details.ProjectInputs, Global.details.UserManuals, Global.details.TestReports,Global.details.ASILlevel };
                    common_func("Tool Details");
                }
            }

            void common_func(string sheetname)
            {
                ////Excel._Worksheet xlWorksheet = xlWorkbook.Sheets[sheetname];
                ////Excel.Range xlRange = xlWorksheet.UsedRange;
                //for (int i = 0; i < SearchItems.Length; i++)
                //{
                //    var currentFind = xlRange.Find(SearchItems[i]);
                //    var row = currentFind.Row;
                //    var column = currentFind.Column;

                //    xlWorksheet.Cells[row, column + 1] = Values[i];

                //    Console.WriteLine("Row: " + row);
                //    Console.WriteLine("Coloumn: " + column);

                //}

            }

            //xlWorkbook.Save();
            //xlWorkbook.Close(true);
            //xlApp.Quit();



        }


    }
}
