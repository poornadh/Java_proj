﻿using System;
using System.Collections.Generic;
using System.Collections.ObjectModel;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FS_1
{
    /// <summary>
    /// Interaction logic for wpfrevisionhistory.xaml
    /// </summary>
    public partial class wpfrevisionhistory : UserControl
    {
        public wpfrevisionhistory()
        {
            InitializeComponent();
            // dataGrid1.CanUserAddRows = true;
            dataGrid1.ItemsSource = addrow;


        }
        public ObservableCollection<Row> addrow = new ObservableCollection<Row>();


        //public string VersionNo;
        //public string date;
        //public string ChangeDescription;
        //public string PreparedBy;
        //public string ApprovedBy;

        public class Row
        {
            public string Version_No { get; set; }
            public string Date { get; set; }
            public string Change_Description { get; set; }
            public string Prepared_By { get; set; }
            public string Approved_By { get; set; }
        }

        private void dataGrid1_Loaded(object sender, RoutedEventArgs e)
        {
            //dataGrid1.ItemsSource = addrow;
           // dataGrid1.ColumnHeaderHeight = 30;

        }


        //Add new row to datagrid
        private void Button_Click(object sender, RoutedEventArgs e)
        {
            addrow.Add(new Row() { Version_No = "", Date = "", Change_Description = "", Prepared_By = "", Approved_By = "" });
        }

        private void dataGrid1_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

        }

        private void ToolBar_Loaded(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.ToolBar toolBar = sender as System.Windows.Controls.ToolBar;
            var overflowGrid = toolBar.Template.FindName("OverflowGrid", toolBar) as FrameworkElement;
            if (overflowGrid != null)
            {
                overflowGrid.Visibility = Visibility.Collapsed;
            }
            var mainPanelBorder = toolBar.Template.FindName("MainPanelBorder", toolBar) as FrameworkElement;
            if (mainPanelBorder != null)
            {
                mainPanelBorder.Margin = new Thickness();
            }

        }

        public bool IsEditingRow


        {


            get { return (bool)GetValue(EditingRowProperty); }


            set { SetValue(EditingRowProperty, value); }


        }





        public static readonly DependencyProperty EditingRowProperty =


            DependencyProperty.Register(


              "IsEditingRow",


              typeof(bool),


              typeof(wpfrevisionhistory),


              new FrameworkPropertyMetadata(false, null, null));
    }
}
