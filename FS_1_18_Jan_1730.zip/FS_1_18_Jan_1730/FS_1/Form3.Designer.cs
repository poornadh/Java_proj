﻿namespace FS_1
{
    partial class Form3
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            this.dataGridView1 = new System.Windows.Forms.DataGridView();
            this.Tool_Use_Case_ID = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tool_Use_Case = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Potential_Malfunction_or_Erroneous_Output = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Tool_Impact = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.Reason_for_ti = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.tool_error_detection = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.reason_td = new System.Windows.Forms.DataGridViewTextBoxColumn();
            this.addnewrow = new System.Windows.Forms.Button();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridView1
            // 
            this.dataGridView1.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            this.dataGridView1.Columns.AddRange(new System.Windows.Forms.DataGridViewColumn[] {
            this.Tool_Use_Case_ID,
            this.Tool_Use_Case,
            this.Potential_Malfunction_or_Erroneous_Output,
            this.Tool_Impact,
            this.Reason_for_ti,
            this.tool_error_detection,
            this.reason_td});
            this.dataGridView1.Location = new System.Drawing.Point(-1, -1);
            this.dataGridView1.Name = "dataGridView1";
            this.dataGridView1.Size = new System.Drawing.Size(800, 452);
            this.dataGridView1.TabIndex = 0;
            // 
            // Tool_Use_Case_ID
            // 
            this.Tool_Use_Case_ID.DividerWidth = 1;
            this.Tool_Use_Case_ID.HeaderText = "Tool Use Case ID";
            this.Tool_Use_Case_ID.Name = "Tool_Use_Case_ID";
            // 
            // Tool_Use_Case
            // 
            this.Tool_Use_Case.HeaderText = "Tool Use Case";
            this.Tool_Use_Case.Name = "Tool_Use_Case";
            // 
            // Potential_Malfunction_or_Erroneous_Output
            // 
            this.Potential_Malfunction_or_Erroneous_Output.HeaderText = "Potential Malfunction or Erroneous Output";
            this.Potential_Malfunction_or_Erroneous_Output.Name = "Potential_Malfunction_or_Erroneous_Output";
            // 
            // Tool_Impact
            // 
            this.Tool_Impact.HeaderText = "Tool Impact";
            this.Tool_Impact.Name = "Tool_Impact";
            // 
            // Reason_for_ti
            // 
            this.Reason_for_ti.HeaderText = "Reason For Selecting TI";
            this.Reason_for_ti.Name = "Reason_for_ti";
            // 
            // tool_error_detection
            // 
            this.tool_error_detection.HeaderText = "Tool error Detection";
            this.tool_error_detection.Name = "tool_error_detection";
            // 
            // reason_td
            // 
            this.reason_td.HeaderText = "Reason For Selecting TD";
            this.reason_td.Name = "reason_td";
            // 
            // addnewrow
            // 
            this.addnewrow.Location = new System.Drawing.Point(672, 398);
            this.addnewrow.Name = "addnewrow";
            this.addnewrow.Size = new System.Drawing.Size(75, 23);
            this.addnewrow.TabIndex = 1;
            this.addnewrow.Text = "ADD ROW";
            this.addnewrow.UseVisualStyleBackColor = true;
            this.addnewrow.Click += new System.EventHandler(this.addnewrow_Click);
            // 
            // Form3
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(6F, 13F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Font;
            this.ClientSize = new System.Drawing.Size(800, 450);
            this.Controls.Add(this.addnewrow);
            this.Controls.Add(this.dataGridView1);
            this.Name = "Form3";
            this.ShowIcon = false;
            this.Text = "Feature";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridView1)).EndInit();
            this.ResumeLayout(false);

        }

        #endregion

        private System.Windows.Forms.DataGridView dataGridView1;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tool_Use_Case_ID;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tool_Use_Case;
        private System.Windows.Forms.DataGridViewTextBoxColumn Potential_Malfunction_or_Erroneous_Output;
        private System.Windows.Forms.DataGridViewTextBoxColumn Tool_Impact;
        private System.Windows.Forms.DataGridViewTextBoxColumn Reason_for_ti;
        private System.Windows.Forms.DataGridViewTextBoxColumn tool_error_detection;
        private System.Windows.Forms.DataGridViewTextBoxColumn reason_td;
        private System.Windows.Forms.Button addnewrow;
    }
}