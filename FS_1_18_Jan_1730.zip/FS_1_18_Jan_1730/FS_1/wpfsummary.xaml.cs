﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;
using FS_1;

namespace FS_1
{

    /// <summary>
    /// Class 
    /// </summary>
   
    public partial class wpfsummary : UserControl
    {
       
        public wpfsummary()
        {
            InitializeComponent();
            this.DataContext = Global.summary;
        }
        
        private void Clear_Option_Summ(object sender, RoutedEventArgs e)
        {
            projectname.Clear();
            customername.Clear();
            managername.Clear();
            toolname.Clear();
            toolversion.Clear();
            docId.Clear(); docVer.Clear(); date.Clear(); docOverview.Clear();
          
         

        }

        private void Save_Option_Summ(object sender, RoutedEventArgs e)
        {

            Global.check1++;
          //  Back_End b_end = new Back_End();
            //b_end.CreateSummaryObjects();

        }

        private void Button_Click_2(object sender, RoutedEventArgs e)
        {

        }
    }
}
