﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Windows;
//using System.Windows.Controls;
using System.Windows.Forms;
using System.Windows.Input;
using System.Windows.Navigation;
using System.Collections.ObjectModel;
using System.Windows.Controls;

namespace FS_1
{
    /// <summary>
    /// Interaction logic for MainWindow.xaml
    /// </summary>      
    /// 
   /* public class Global
    {
        public static int check1 = 0;
        public static int check2 = 0;
        public static int np_count = 0;
        public static int summ_count = 0;
        public static int tool_count = 0;
        public static System.Windows.Controls.TextBox t1;
        public static string filename;
        public static string filename_without_extension;
        public static string toolname=null;

    }*/

    public partial class MainWindow : Window
    {
       
       

        public Dictionary<int,string> Projects = new Dictionary<int, string>();
        public List<string> ProjectName = new List<string>();
        public List<int> integer = new List<int>();
        public string projectName;
        public string fsn;
        public string ParentName;
        public string selectedItem;
        public string subparentname;
        public string fsname;
        TreeViewItem NewTreeItem = null;
        TreeViewItem Feature = null;
        TreeViewItem TCL = null;
        NewProject projectForm;

        public MainWindow()
        {
            InitializeComponent();
            //DataContext = new Functional_Safety() { Header = "Functional Safety" };
            //TreeView1.DataContext = new Functional_Safety() { Header = "Functional Safety" };
        }

        private void MenuNewProject_Click(object sender, RoutedEventArgs e)
        {
            Savediaglogbox();
            //NewProjectForm();
        }

        //Function to add use case
       /* public void AddUseCase()  
        {
            
            TreeViewItem UseCase = new TreeViewItem() { Header = "Use Case" };
            Feature.Items.Add(UseCase);
            UseCase.Name = "AddUseCase";
        }

        public void AddUseCase1(TreeViewItem tree)
        {

            System.Windows.MessageBox.Show(tree.ToString());
            TreeViewItem usecase = new TreeViewItem() { Header = tree.ToString() };
            usecase.Items.Add("Use Case");
        }

        //To add use case along with given input from Form2 
        public void AddUseCaseWName()
        {
            Form2 UseCaseForm = new Form2();
            DialogResult result = UseCaseForm.ShowDialog();

            if (result == System.Windows.Forms.DialogResult.OK)
            {
                var a = UseCaseForm.NumOfUseCases.Value;

                //TreeViewItem tree = new TreeViewItem();
                //tree = ((TreeViewItem)((TreeViewItem)TreeView1.SelectedItem).Parent);

                for (int count = 1; count <= a; count = count + 1)
                {
                    //AddUseCase1(tree);
                   // AddUseCase();
                }
            }
        }*/

        //This function adds Feature and UseCase
        public void AddFeatUseCase( )
        {

            Form1 FeatNameForm = new Form1();
            DialogResult result = FeatNameForm.ShowDialog();
            string namewText = FeatNameForm.textBox1.Text;


            if (!string.IsNullOrEmpty(namewText) & result == System.Windows.Forms.DialogResult.OK)
            {

                TreeViewItem Featurelst = new TreeViewItem();
                Featurelst.Header = namewText;
                Featurelst.Name = "_AddFeat";
                Feature.Items.Add(Featurelst);

                //var a = FeatNameForm.NumericUpDown1.Value;


                //for (int count = 1; count <= a; count = count + 1)
                //{
                //    AddUseCase();
                //}
            }
            else if (result == System.Windows.Forms.DialogResult.OK & string.IsNullOrEmpty(namewText))
            {
                //TreeViewItem
                var Featurelst = new TreeViewItem();
                Featurelst.Header = "Feature";
                Featurelst.Name = "_AddFeat";
                Feature.Items.Add(Featurelst);
               
                // AddUseCase();

            }
        }

        public void RenameItem()
        {
            RenameDialogBox Rename = new RenameDialogBox();
            Rename.ShowDialog();
            if (!string.IsNullOrEmpty(Rename.textBox1.Text))
            {
                ((TreeViewItem)TreeView1.SelectedItem).Header = Rename.textBox1.Text;
            }
            else
            {
                System.Windows.Forms.MessageBox.Show(TreeView1.SelectedItem.ToString());
                System.Windows.Forms.MessageBox.Show("Name cannot be empty!");
            }
        }
        public static int l = -1;
        public string[] NPName = new string[50];

        public void Opendialogbox()
        {
            System.Windows.Forms.OpenFileDialog openFileDlg = new System.Windows.Forms.OpenFileDialog();

            openFileDlg.DefaultExt = ".afs";

            openFileDlg.Filter = "AFS documents (.afs)|*.afs";

            openFileDlg.Multiselect = true;



            DialogResult opendialogResult = openFileDlg.ShowDialog();

            if (opendialogResult == System.Windows.Forms.DialogResult.OK)
            {
               
                foreach (string filename in openFileDlg.FileNames)
                {


                    NewTreeItem = new TreeViewItem() { Header = System.IO.Path.GetFileNameWithoutExtension(filename) };
                   




                    TCL = new TreeViewItem() { Header = "TCL" };
                    TCL.Name = "tcl_name";

                    NewTreeItem.Items.Add(TCL);

                    TreeViewItem ToolNAme = new TreeViewItem() { Header = Global.toolname };
                    TCL.Items.Add(ToolNAme);

                    TreeViewItem Summary = new TreeViewItem() { Header = "Summary" };
                    Summary.Name = "_Summary";
                    ToolNAme.Items.Add(Summary);


                    TreeViewItem RevisionHistory = new TreeViewItem() { Header = "Revision History" };
                    RevisionHistory.Name = "_RevisionHistory";
                    ToolNAme.Items.Add(RevisionHistory);

                    TreeViewItem ToolDetails = new TreeViewItem() { Header = "Tool Details" };
                    ToolDetails.Name = "_ToolDetails";
                    ToolNAme.Items.Add(ToolDetails);

                    TreeViewItem AnalysisSummary = new TreeViewItem() { Header = "Analysis Summary" };
                    AnalysisSummary.Name = "_AnalysisSummary";
                    ToolNAme.Items.Add(AnalysisSummary);


                    Feature = new TreeViewItem();
                    Feature.Header = "Feature";
                    Feature.Name = "_AddFeat";
                    ToolNAme.Items.Add(Feature);

                   // AddUseCase();
                }

            }
        }


        public void Savediaglogbox()
        {
            System.Windows.Forms.SaveFileDialog saveFileDlg = new System.Windows.Forms.SaveFileDialog();

            saveFileDlg.DefaultExt = ".afs";

            saveFileDlg.Filter = "AFS documents (.afs)|*.afs";

            saveFileDlg.Title = "Save";

            DialogResult dialogResult = saveFileDlg.ShowDialog();

            if (dialogResult == System.Windows.Forms.DialogResult.OK)
            {

                File.Create(saveFileDlg.FileName);
                Global.filename = System.IO.Path.GetFileName(saveFileDlg.FileName);
                Global.filename_without_extension= System.IO.Path.GetFileNameWithoutExtension(saveFileDlg.FileName);
                //Project fs_name = new Project();
                //fs_name.project_name.Add(Global.filename);


                NewProjectForm();

            }
        }

        //To be removed in case the TreeViewpopulating is working properly in below function
        public void CreateInitialTV(String val)
        {

            //projectName = project.textBox1.Text;
            //string toolname = project.textBox2.Text;
            //System.Windows.MessageBox.Show(toolname);
            //ProjectName.Add(projectName);
            //ObservableCollection<Project> p = new ObservableCollection<Project>();
            //Project Mainproject = new Project() { header = projectName };
            //Mainproject.header = projectName;
            //Project Selectactivity = new Project() { header = val };
            //Project Toolname = new Project() { header = toolname };
            //Project Feature = new Project() { header = "Features" };
            //Mainproject.items.Add(Selectactivity);
            //Selectactivity.items.Add(Toolname);
            //Toolname.items.Add(new Project() { header = "Summary" });
            //Toolname.items.Add(new Project() { header = "Tool Details" });
            //Toolname.items.Add(new Project() { header = "Revision History" });
            //Toolname.items.Add(new Project() { header = "Analysis Summary" });
            //Toolname.items.Add(Feature);
            //TreeView1.Items.Add(Mainproject);
            //System.Windows.MessageBox.Show(Mainproject.items.Count + "");

        }

        //Creating acustomTreeViewItem
        //public class CustomTreeViewItem : TreeViewItem
        //{
        //    public int index;
        //    public int level;
        //    public string NodeText;
        //    public string OtherData;

        //}

        public class CustomTreeViewItem_Old : TreeViewItem
        {
            public int index { get; set; }
            public int level { get; set; }
            public string otherData { get; set; }
            public int id { get; set; }
        }

        //Creatin a list of CustomTreeViewItem
        ObservableCollection<CustomTreeViewItem> TvData = new ObservableCollection<CustomTreeViewItem>();

        //List<CustomTreeViewItem> TvDataParent;
        public void ClearAllNodes()
        {
            TreeView1.Items.Clear();
        }

        public void ClearOneNode(int index)
        {
            //int Tvcount = Func_Safety.Items.Count;
            TreeView1.Items.RemoveAt(index);

        }

        //A sample implementation to populate the TreeView
        public void populateBaseNodes()
        {
            int i;
            int count = TreeView1.Items.Count;

            //Sample treevieitem to check functionalities
            TreeViewItem rte = new TreeViewItem();

            //TreeView1.BeginUpdate();
            //TvData.Count given number of elements in the list
            for (i = 0; i < TvData.Count; i++)
            {
                //if (TvData[i].level == 0)
                //{
                //    TreeView1.Items.Add(TvData[i].Header);
                //    //TreeView1.Items.GetItemAt(TvData[i].index)
                //        //Add(TvData[i].NodeText, TvData[i].NodeText);
                //    //TreeView1.Nodes[tvData.Nodes.Count - 1].Tag = L[i];
                //}
            }

            for (i = 0; i < TreeView1.Items.Count; i++) ;
                //populateChilds(TreeView1.Items.GetItemAt(TvData[i].index));
            //tvData.EndUpdate();
            //tvData.Refresh();
        }

        public void populateChilds(Object ParentItem)
        {

        }

        ObservableCollection<Sheets> GetSheetsCollection()
        {
            // ObservableCollection<Sheets> SheetsList = new ObservableCollection<Sheets>();
            Sheets InsSheets = new Sheets();
            //InsSheets.Ins_Tool.SheetsCollection = new ObservableCollection<Sheets>();
            InsSheets.Ins_Tool.SheetsCollection.Add(new Sheets() { Header = InsSheets.SummaryObjects.Header, UId = InsSheets.SummaryObjects.Header + InsSheets.Ins_Tool.SheetsCollection.Count });
            InsSheets.Ins_Tool.SheetsCollection.Add(new Sheets() { Header = InsSheets.RevisionHistoryObjects.Header, UId = InsSheets.RevisionHistoryObjects.Header + InsSheets.Ins_Tool.SheetsCollection.Count });
            InsSheets.Ins_Tool.SheetsCollection.Add(new Sheets() { Header = InsSheets.AnalysisSummaryObjects.Header, UId = InsSheets.AnalysisSummaryObjects.Header + InsSheets.Ins_Tool.SheetsCollection.Count });
            InsSheets.Ins_Tool.SheetsCollection.Add(new Sheets() { Header = InsSheets.ToolDetailsObjects.Header, UId = InsSheets.ToolDetailsObjects.Header + InsSheets.Ins_Tool.SheetsCollection.Count });
            InsSheets.Ins_Tool.SheetsCollection.Add(new Sheets() { Header = InsSheets.FeatureObjects.Header, UId = InsSheets.FeatureObjects.Header + InsSheets.Ins_Tool.SheetsCollection.Count });
            //SheetsList.Add(new Sheets() { Header = InsSheets.SummaryObjects.Header });
            //SheetsList.Add(new Sheets() { Header = InsSheets.RevisionHistoryObjects.Header });
            //SheetsList.Add(new Sheets() { Header = InsSheets.AnalysisSummaryObjects.Header });
            //SheetsList.Add(new Sheets() { Header = InsSheets.ToolDetailsObjects.Header });
            //SheetsList.Add(new Sheets() { Header = InsSheets.FeatureObjects.Header });
            return InsSheets.Ins_Tool.SheetsCollection;
        }


        ObservableCollection<Tool> GetToolcollection()
        {
            ObservableCollection<Sheets> InsSheetsCollection = GetSheetsCollection();
            // System.Windows.MessageBox.Show("The sheets collection has : " + InsSheetsCollection.Count);
            Selectactivity InstanceSA = new Selectactivity();
            //InstanceSA.ToolsCollection = new ObservableCollection<Tool>();
            InstanceSA.ToolsCollection.Add(new Tool() { Header = projectForm.textBox2.Text, ToolName = "RTE TCG", SheetsCollection = InsSheetsCollection });
            // InstanceSA.ToolsCollection.Add(new Tool() {Header = "RTE Code Generator", ToolName = "RTE CG", SheetsCollection = InsSheetsCollection});

            return InstanceSA.ToolsCollection;
        }

        ObservableCollection<Selectactivity> GetSelectactivitiesCollection()
        {
            // ObservableCollection<Sheets> InsSheetsCollection = GetSheetsCollection();
            ObservableCollection<Tool> InsToolCollection = GetToolcollection();
            Project InstanceProject = new Project();
            //InstanceProject.ActivityCollection = new ObservableCollection<Selectactivity>();
            InstanceProject.ActivityCollection.Add(new Selectactivity() { Header = projectForm.listBox1.SelectedItem.ToString(), ToolsCollection = InsToolCollection });

            return InstanceProject.ActivityCollection;
        }

        public ObservableCollection<Project> GetProjectCollection()
        {
            //ObservableCollection<Sheets> InsSheetsCollection = GetSheetsCollection();
            //ObservableCollection<Tool> InsToolCollection = GetToolcollection();
            ObservableCollection<Selectactivity> InsSelectActivitiesCollection = GetSelectactivitiesCollection();
            Functional_Safety InsFuncSafety = new Functional_Safety();
            InsFuncSafety.ProjectCollection.Add(new Project() { Header = Global.filename_without_extension, ActivityCollection = InsSelectActivitiesCollection });
            return InsFuncSafety.ProjectCollection;
        }


        public void NewProjectForm()
        {
            projectForm = new NewProject();
            projectForm.textBox1.Text = Global.filename_without_extension;

            DialogResult NewdialogResult = projectForm.ShowDialog();
            
            Global.toolname = projectForm.textBox2.Text;
            
            string val = projectForm.listBox1.SelectedItem.ToString();
            
            if (projectForm.DialogResult == System.Windows.Forms.DialogResult.OK)
            {
               
               

                //CustomTreeViewItem FunctionalSafety = new CustomTreeViewItem();
                ////CreateInitialTV(val);
                //TreeView1.Items.Add(FunctionalSafety);
                //Project project1 = new Project() { Header = "Project_Name" };

                Functional_Safety InsFS = new Functional_Safety() { Header = "Functional Safety" };
                
                InsFS.ProjectCollection = GetProjectCollection();
               // System.Windows.MessageBox.Show("The project collection count is: " + InsFS.ProjectCollection.Count);
                this.DataContext = InsFS;
                newfeature.IsEnabled = true;
                //TreeView1.ItemsSource = InsFS.ProjectCollection;

                //this.DataContext = InsFS;
                //this.DataContext = new Functional_Safety() { Header = "Functional Safety" };
                //this.DataContext = new Functional_Safety() { Header = "Functional Safety" };
                //Project InsProject = new Project();


                //Functional_Safety InstFunctionalSafety = new Functional_Safety() { Header="Functional Safety" };

                //Selectactivity instanceSelectActivity = new Selectactivity() { Header="Select Activity"};
                //Sheets InstanceDetails = new Sheets() { };
                //Feature InstanceFeature = new Feature();
                //Tool InstanceTool = new Tool();
                //InstFunctionalSafety.Items.Add(project1);
                //project1.Members.Add(instanceSelectActivity);
                //instanceSelectActivity.Tools.Add(InstanceTool);
                //InstanceTool.DetailsToolNodes.Add(InstanceDetails);
                //InstanceTool.FeatureNodeCollection.Add(InstanceFeature);
                //InstanceFeature.InstanceUsecase.Add(InstanceFeature.AddUseCase());



                //var abc = InstanceFeature.InstanceUsecase.ToString();
                //System.Windows.Forms.MessageBox.Show("abc is "+ InstanceFeature.AddUseCase());

                ////InstanceDetails.
                ////Tool instanceTool = new Tool();
                //InstanceDetails.Ins_Tool.DetailsToolNodes.Add(InstanceDetails); 

                //System.Windows.Forms.MessageBox.Show("Members has :"+project1.Members.ToString());
                ////TreeView1.Items.Add(project1);             
                //TreeView1.DataContext = project1;
                ////TreeView1.ItemsSource = project1;

                //TreeView1.Items.Add(InstFunctionalSafety);
                //project1.AddProject(FunctionalSafetyTv, 1);
                //project1.createDefaultSheets();
                //ClearAllNodes();
                //---------------------------------------------------------------------------------------------------
                //Selectactivity SA1 = new 

                //Project Project_name = new Project() ;
                //Project_name.SetName(project.textBox1.Text);
                // Selectactivity tCL = new Selectactivity() { Header = val };

                //Project_name.items.Add(tCL);
                //Tool tool_name = new Tool() { ToolName = toolname };
                //tCL.items.Add(tool_name);
                //tool_name.items.Add(new Details() { Header = "Summary" });
                //tool_name.items.Add(new Details() { Header = "Tool Details" });
                //tool_name.items.Add(new Details() { Header = "Revision History" });
                //tool_name.items.Add(new Details() { Header = "Analysis Summary" });
                //Details details = new Details() { Header = "Features" };
                //tool_name.items.Add(details);
                //Functional_Safety.Items.Add(Project_name);
                ////TreeView1.ItemsSource = _Safety;

                //NewTreeItem = new TreeViewItem() { Header = projectName };
                //Functional_Safety.Items.Add(NewTreeItem);




                //TCL = new TreeViewItem() { Header = val };
                //TCL.Name = "tcl_name";
                //NewTreeItem.Items.Add(TCL);

                //Toolname = new TreeViewItem() { Header = Global.toolname };
                //TCL.Items.Add(Toolname);

                //TreeViewItem Summary = new TreeViewItem() { Header = "Summary" };
                //Summary.Name = "_Summary";
                //Toolname.Items.Add(Summary);


                //TreeViewItem RevisionHistory = new TreeViewItem() { Header = "Revision History" };
                //RevisionHistory.Name = "_RevisionHistory";
                //Toolname.Items.Add(RevisionHistory);

                //TreeViewItem ToolDetails = new TreeViewItem() { Header = "Tool Details" };
                //ToolDetails.Name = "_ToolDetails";
                //Toolname.Items.Add(ToolDetails);

                //TreeViewItem AnalysisSummary = new TreeViewItem() { Header = "Analysis Summary" };
                //AnalysisSummary.Name = "_AnalysisSummary";
                //Toolname.Items.Add(AnalysisSummary);


                //Feature = new TreeViewItem();
                //Feature.Header = "Feature";
                //Feature.Name = "_AddFeat";
                //Toolname.Items.Add(Feature);

                // AddUseCase();

                //Calling create TCL object function
                Back_End b_end = new Back_End();
               // b_end.CreateProjectObjects();


            }
            //else
            //{
            //    project.Close();
            //}


        }



        public void path(string SI, string SP, string P)
        {

            if (P == null)
            {
                if (SP == null)
                {
                    combo.Text = SI;
                }
                else
                {
                    combo.Text = SP + "->" + SI;
                }
            }
            else
            {
                combo.Text = P + "->" + SP + "->" + SI;
            }
        }


        private void MenuNewFile_Click(object sender, RoutedEventArgs e)
        {
            Savediaglogbox();
        }

        private void MenuOpenProject_Click(object sender, RoutedEventArgs e)
        {
            Opendialogbox();
        }



        private void MenuOpenFile_Click(object sender, RoutedEventArgs e)
        {
            Opendialogbox();
        }

        private void MenuSave_Click(object sender, RoutedEventArgs e)
        {
            Savediaglogbox();
        }

        private void MenuExit_Click(object sender, RoutedEventArgs e)
        {
            Close_Window();
        }

        private void Close_Window()
        {
            this.Close();
        }

        private void TbNew_Click(object sender, RoutedEventArgs e)
        {
            Savediaglogbox();
            // NewProjectForm();
        }

        private void TbOpen_Click(object sender, RoutedEventArgs e)
        {
            Opendialogbox();
        }

        private void TbSave_Click(object sender, RoutedEventArgs e)
        {
            // Savediaglogbox();
          
            System.Windows.Forms.SaveFileDialog saveFileDlg = new System.Windows.Forms.SaveFileDialog();

            saveFileDlg.DefaultExt = ".afs";

            saveFileDlg.Filter = "AFS documents (.afs)|*.afs";

            saveFileDlg.Title = "save as";

            saveFileDlg.FileName = Global.filename;

            DialogResult dialogResult = saveFileDlg.ShowDialog();


            if (dialogResult == System.Windows.Forms.DialogResult.OK)
            {

                File.Create(saveFileDlg.FileName);
               

            }

        }

        private void TbExport_Click(object sender, RoutedEventArgs e)
        {
            Generate_Excel generation = new Generate_Excel();
            generation.Generate_ExcelSheet();
        }


        //Adding the select activity to the current opened file


        private void PbNewPackage_Click(object sender, RoutedEventArgs e)
        {
            
            AddElement();
            
        }

        //Adding New Activity to Project
        public void AddElement()
        {


            TreeViewItem tvi = TreeView1.Tag as TreeViewItem;
            //System.Windows.MessageBox.Show(tvi.Header.ToString());
            
           // string PName = ((TreeViewItem)TreeView1.SelectedItem).Header.ToString();
            
            NewProject Addelement = new NewProject();
            Addelement.textBox1.Text = Global.filename;
            DialogResult NewdialogResult = Addelement.ShowDialog();
            string toolName = Addelement.textBox2.Text;
            string val = Addelement.listBox1.SelectedItem.ToString();


            if (NewdialogResult == System.Windows.Forms.DialogResult.OK)
            {

                if (val == "Tool Confidence Level")
                {
                    val = "TCL";
                }
                else if (val == "Tool Qualification")
                {
                    val = "TQ";
                }
                else if (val == "Safety Analysis")
                {
                    val = "SA";
                }

                //Selectactivity tCL = new Selectactivity() { Header = val };
                //Project vs = new Project();
                //vs.SetName( Addelement.textBox1.Text);
                //Tool tool_name = new Tool() { ToolName ="tool" };
                //Functional_Safety fs = new Functional_Safety();
                
                //tool_name.items.Add(new Details() { Header = "Summary" });
                //tool_name.items.Add(new Details() { Header = "Tool Details" });
                //tool_name.items.Add(new Details() { Header = "Revision History" });
                //tool_name.items.Add(new Details() { Header = "Analysis Summary" });
                //Details details = new Details() { Header = "Features" };
                
                //tool_name.items.Add(details);
                //tCL.items.Add(tool_name);
                //vs.items.Add(tCL);
                //fs.items.Add(vs);
                //TCL = new TreeViewItem() { Header = val };
                //TCL.Name = "tcl_name";
                //NewTreeItem.Items.Add(TCL);

                //Toolname = new TreeViewItem() { Header = toolName };
                //TCL.Items.Add(Toolname);

                //TreeViewItem Summary = new TreeViewItem() { Header = "Summary" };
                //Summary.Name = "_Summary";
                //Toolname.Items.Add(Summary);


                //TreeViewItem RevisionHistory = new TreeViewItem() { Header = "Revision History" };
                //RevisionHistory.Name = "_RevisionHistory";
                //Toolname.Items.Add(RevisionHistory);

                //TreeViewItem ToolDetails = new TreeViewItem() { Header = "Tool Details" };
                //ToolDetails.Name = "_ToolDetails";
                //Toolname.Items.Add(ToolDetails);

                //TreeViewItem AnalysisSummary = new TreeViewItem() { Header = "Analysis Summary" };
                //AnalysisSummary.Name = "_AnalysisSummary";
                //Toolname.Items.Add(AnalysisSummary);


                //Feature = new TreeViewItem();
                //Feature.Header = "Feature";
                //Feature.Name = "_AddFeat";
                //Toolname.Items.Add(Feature);

                // AddUseCase();

            }
            else
            {
                Addelement.Close();
            }
        }
        
       
        public void Addingnewtool( string str)
        {
            TreeViewItem toolname = new TreeViewItem() { Header = str };
            TCL.Items.Add(toolname);
            TreeViewItem Summary = new TreeViewItem() { Header = "Summary" };
            Summary.Name = "_Summary";
            toolname.Items.Add(Summary);


            TreeViewItem RevisionHistory = new TreeViewItem() { Header = "Revision History" };
            RevisionHistory.Name = "_RevisionHistory";
            toolname.Items.Add(RevisionHistory);

            TreeViewItem ToolDetails = new TreeViewItem() { Header = "Tool Details" };
            ToolDetails.Name = "_ToolDetails";
            toolname.Items.Add(ToolDetails);

            TreeViewItem AnalysisSummary = new TreeViewItem() { Header = "Analysis Summary" };
            AnalysisSummary.Name = "_AnalysisSummary";
            toolname.Items.Add(AnalysisSummary);


            Feature = new TreeViewItem();
            Feature.Header = "Feature";
            Feature.Name = "_AddFeat";
            toolname.Items.Add(Feature);

           // AddUseCase();
        }

        //Adding new test element to projectname
        private void PbAddElement_Click(object sender, RoutedEventArgs e)
        {
            try
            {
                TreeViewItem SelectedItem = ((TreeViewItem)TreeView1.SelectedItem);
                string ItemName = SelectedItem.Header.ToString();
                System.Windows.MessageBox.Show(ItemName);

                NewProject np = new NewProject();
                np.textBox1.Text = Global.filename;
               

                string addfeat = "Feature";
                string usecase = "Use Case";

               
                    
                    if (ItemName != "")
                    {

                    if (true == Equals(ItemName, addfeat))
                    {

                        AddFeatUseCase();
                    }
                    else if (true == Equals(ItemName, usecase))
                    {
                      //  AddUseCaseWName();
                    }
                    else if (ItemName == "TCL")
                    {
                        DialogResult NewdialogResult = np.ShowDialog();
                        string str = np.textBox2.Text;

                        if (NewdialogResult == System.Windows.Forms.DialogResult.OK)
                        {
                            Addingnewtool(str);
                        }
                        else
                        {
                            np.Close();
                        }
                    }
                    else if(ItemName == "TQ")
                    {
                        DialogResult NewdialogResult = np.ShowDialog();
                        string str = np.textBox2.Text;
                        if (NewdialogResult == System.Windows.Forms.DialogResult.OK)
                        {
                            Addingnewtool(str);
                        }
                        else
                        {
                            np.Close();
                        }
                    }
 
            }
        }

            catch (Exception)
            {
                if (selectedItem == null)
                {
                    (TreeView1.ItemContainerGenerator.ContainerFromIndex(2) as TreeViewItem).IsSelected = true;
                }

            }

        }

        private void PbDelete_Click(object sender, RoutedEventArgs e)
        {
           
                ((TreeViewItem)((TreeViewItem)TreeView1.SelectedItem).Parent).Items.RemoveAt(((TreeViewItem)((TreeViewItem)TreeView1.SelectedItem).Parent).Items.IndexOf(TreeView1.SelectedItem));
                selectedItem = ((TreeViewItem)TreeView1.SelectedItem).Header.ToString();
                
            
        }

        private void NewBinding_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            Savediaglogbox();
        }

        private void OpenBinding_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            Opendialogbox();
        }

        private void SaveBinding_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            Savediaglogbox();
        }

        private void ExitBinding_Executed(object sender, ExecutedRoutedEventArgs e)
        {
            Close_Window();
        }


        private void closeTabItem(TabItem item)
        {

            if (item != null)
            {

                // find the parent tab control

                System.Windows.Controls.TabControl tabControl = item.Parent as System.Windows.Controls.TabControl;

                if (tabControl != null)

                    tabControl.Items.Remove(item); // remove tabItem

            }
        }

        public class ActionTabItem
        {
            // This will be the text in the tab control
            public string Header { get; set; }
            // This will be the content of the tab control It is a UserControl whits you need to create manualy
            public System.Windows.Controls.UserControl Content { get; set; }
            //This will show from which file the content is
            public string name { get; set; }
            //this will set the title name
            public string title { get; set; }
        }

        

        public void TreeView1_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

          // System.Windows.MessageBox.Show("Entered By Double Click!!" + TreeView1.Items.Count + TreeView1.SelectedItem.GetType());
            MouseandKey();
        }
        private void Key_Up(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == Key.Enter)
            {
                if (TreeView1.SelectedItem == NewTreeItem)
                {
                    if (TreeView1.SelectedItem == NewTreeItem && NewTreeItem.IsExpanded == true)
                    {
                        NewTreeItem.IsExpanded = false;
                    }

                    else

                    {
                        NewTreeItem.IsExpanded = true;
                    }
                }

               

                else if (TreeView1.SelectedItem == Feature)
                {
                    if (TreeView1.SelectedItem == Feature && Feature.IsExpanded == true)
                    {
                        Feature.IsExpanded = false;
                    }

                    else

                    {
                        Feature.IsExpanded = true;
                    }
                }

                else
                {
                    TreeView1_Enterkey(sender, e);
                }

            }

        }

        private void TreeView1_Enterkey(object sender, System.Windows.Input.KeyEventArgs e)
        {
            MouseandKey();
        }
        public static int i;
        public static int j;

        // private object MessageBoxOption;

        public void MouseandKey()
        {
            try
            {
              
                //string selectedItem = (((TreeViewItem)TreeView1.SelectedItem).Name.ToString());
                //string subparentname = ((TreeViewItem)((TreeViewItem)TreeView1.SelectedItem).Parent).Header.ToString();
                //string fsname = ((TreeViewItem)((TreeViewItem)((TreeViewItem)((TreeViewItem)TreeView1.SelectedItem).Parent).Parent).Parent).Header.ToString();
                //string ParentName = ((TreeViewItem)((TreeViewItem)((TreeViewItem)TreeView1.SelectedItem).Parent).Parent).Header.ToString();
                //Projects.Add("project");

                string string1 = "Summary";
                string string2 = "Tool Details";
                string string3 = "Revision History";
                string string4 = "Features";
               
                

               // path(selectedItem, subparentname, ParentName);
               //SUMMARY
                if (true == Equals((TreeView1.SelectedItem as Sheets).Header, string1))
                {
                    bool s1 = false;
                    int cnt = tab1.Items.Count;

                    //foreach (string value in Projects)
                    //{
                    //    // string store = null;
                    //    s1 = value.Equals(ParentName+ subparentname + selectedItem);
                    //    // store = ParentName;
                    //    if (s1 == true)
                    //    {
                    //        break;
                    //    }
                    //}
                    

                    SummaryViewModel display = new SummaryViewModel();

                    if (s1)
                    {
                         System.Windows.MessageBox.Show("tab is present");
                        //bool s3;
                        //foreach(string i in Project)
                        //{
                        //    s3 = i.Contains(j.ToString());
                        //    if (s3 == true)
                        //    {
                        //        tab1.SelectedIndex =i.ElementAt(0);
                        //        break;
                        //    }
                            
                        //}
                        
                    }
                    //check if tab was already opened and saved
                    else if (Global.check1 > 0 && display != null )
                    {
                        //Summary deserialized_string;
                        //Decryption decrypt_data = new Decryption();
                        //Serialize nw = new Serialize();
                        /* string text = decrypt_data.Decrypter();

                       //  deserialized_string = (Summary)decrypt_data.GetSummary(text);

                         // display = decrypt_data.GetSummary(text);


                         wpfsummaryObj.projectname.Text = deserialized_string.ProjectName;
                         wpfsummaryObj.customername.Text = deserialized_string.CustomerName;
                         wpfsummaryObj.managername.Text = deserialized_string.ProjectManager;
                         wpfsummaryObj.toolname.Text = deserialized_string.ToolName;
                         wpfsummaryObj.toolversion.Text = deserialized_string.ToolVersionNo;
                         wpfsummaryObj.docId.Text = deserialized_string.DocumentId;
                         wpfsummaryObj.docVer.Text = deserialized_string.DocumentVersionNo;
                         wpfsummaryObj.date.Text = deserialized_string.Date;
                         wpfsummaryObj.docOverview.Text = deserialized_string.DocumentOverview;*/
                          wpfsummary wpfsummaryObj = new FS_1.wpfsummary();
                         tab1.Items.Insert(j, new ActionTabItem() { Header = projectForm.textBox2.Text + "/" + "Summary", Content = wpfsummaryObj, name = ParentName + subparentname + selectedItem,title="Summary" });
                        //Project.Add(ParentName + subparentname + selectedItem);
                    }
                    else
                    {
                        
                        wpfsummary wpfsummaryObj = new FS_1.wpfsummary();
                       // wpfsummaryObj.projectname.Text = Global.filename_without_extension;
                       // wpfsummaryObj.toolname.Text = Global.toolname;
                        //count for the tab items
                        int j = cnt;
                        
                        // tab1.Items.Add(new ActionTabItem() { Header = ParentName + "." + subparentname + "." + "Summary", Content = wpfsummaryObj, name = ParentName + selectedItem });
                        


                        //Add the tab items to control
                        tab1.Items.Add( new ActionTabItem() { Header = projectForm.textBox2.Text + "/" + "Summary", Content = wpfsummaryObj, name = "", title = "Summary" });
                        //Set the index of the tabcontrol   
                        tab1.SelectedIndex = j;
                        //Add the tabitem to tabitems list
                        //Projects.Add(j,);

                    }

                }


                //TOOL DETAILS
                if (true == Equals((TreeView1.SelectedItem as Sheets).Header, string2))
                {
                    bool s1 = false;
                    //Count the tab items
                    int cnt = tab1.Items.Count;
                    //foreach (string value in Projects)
                    //{

                    //    s1 = value.Equals(ParentName + subparentname + selectedItem);


                    //    if (s1 == true)
                    //    {
                    //        break;
                    //    }
                    //}


                    Tool_Details display = new Tool_Details();
                    if (s1)
                    {
                        System.Windows.MessageBox.Show("tab is present");
                    }

                    else if (Global.check2 > 0 && display != null)
                    {
                        //Decryption decrypt_data = new Decryption();
                        //Serialize nw = new Serialize();
                        /*  string text = decrypt_data.Decrypter();
                          Tool_Details Deserialized_string;

                        //  Deserialized_string = (Tool_Details)decrypt_data.GetTool(text);


                          wpftooldetailsObj.name.Text = Deserialized_string.Name;
                          wpftooldetailsObj.vendorname.Text = Deserialized_string.VendorName;
                          wpftooldetailsObj.versionNo.Text = Deserialized_string.VersionNo;
                          wpftooldetailsObj.usage.Text = Deserialized_string.UsageEnvironment;
                          wpftooldetailsObj.purchase.Text = Deserialized_string.PurchaseDate;
                          wpftooldetailsObj.installation.Text = Deserialized_string.InstallationDate;
                          wpftooldetailsObj.warranty.Text = Deserialized_string.MaintenanceContract;
                          wpftooldetailsObj.purpose.Text = Deserialized_string.Purpose;
                          wpftooldetailsObj.projectinputs.Text = Deserialized_string.ProjectInputs;
                          wpftooldetailsObj.usermanuals.Text = Deserialized_string.UserManuals;
                          wpftooldetailsObj.testreports.Text = Deserialized_string.TestReports;*/
                        wpftooldetails wpftooldetailsObj = new FS_1.wpftooldetails();
                        tab1.Items.Insert(i, new ActionTabItem() { Header = projectForm.textBox2.Text + "/" + "Tool details", Content = wpftooldetailsObj, name = ParentName + subparentname + selectedItem, title = "Tool Details" });
                         // Project.Add(ParentName + subparentname + selectedItem);
                    }
                    else
                    {

                        wpftooldetails wpftooldetailsObj = new FS_1.wpftooldetails();
                       //wpftooldetailsObj.name.Text = Global.toolname;
                        int i = cnt;
                        //tab1.Items.Add(new ActionTabItem() { Header = ParentName + "." + subparentname + "." + "Tool Details", Content = wpftooldetailsObj, name = ParentName + selectedItem });

                        //insert the tab into the tabcontrol
                        tab1.Items.Add( new ActionTabItem() { Header = projectForm.textBox2.Text + "/" + "Tool details", Content = wpftooldetailsObj, name = ParentName + subparentname + selectedItem, title = "Tool Details" });

                        //set the tabcontrol index
                        tab1.SelectedIndex = i;

                        //Add the tabitems to the list of projects created
                      //  Projects.Add(ParentName + subparentname + selectedItem);

                    }

                }


                if (true == Equals((TreeView1.SelectedItem as Sheets).Header, string3))
                {
                    int cnt = tab1.Items.Count;
                      //  Revision_History revsionhistory = new Revision_History();

                      // revsionhistory.ShowDialog();

                         tab1.Items.Add(new ActionTabItem() { Header = projectForm.textBox2.Text + "/" + "Revision History", Content = new FS_1.wpfrevisionhistory(), name = ParentName + selectedItem, title = "Revision History" });
                    // Project.Add(ParentName + subparentname + selectedItem);
                    tab1.SelectedIndex = cnt;
                }


                if (true == Equals((TreeView1.SelectedItem as Sheets).Header, string4))
                {
                   
                        FeatureWithUsecase form = new FeatureWithUsecase();
                        form.Show();

                        // tab1.Items.Add(new ActionTabItem() { Header = ParentName + "->" + "Feature", Content = new FS_1.wpffeature(), name = ParentName + selectedItem });
                        // Project.Add(ParentName + subparentname + selectedItem);
                    

                }

            }
            catch (Exception)
            {
                //selectedItem = Functional_Safety.ToString();
            }




        }

        private void MessageBox(string text)
        {
            throw new NotImplementedException();
        }


        //To display Add or use case in context menu selectively
        public void TreeView1_MouseRightButtonDown(object sender, MouseButtonEventArgs e)
        {
            Point point = new Point(e.GetPosition(TreeView1).X, e.GetPosition(TreeView1).Y);
            try
            {
                TreeViewItem SelectedItem = ((TreeViewItem)TreeView1.SelectedItem);
                string ItemName = SelectedItem.Name;
                string addfeat = "_AddFeat";
                string usecase = "AddUseCase";
                
                if (point != null && ItemName != null)
                {
                    if (true == Equals(ItemName, addfeat))
                    {
                        CmAddFeat.IsEnabled = true;
                        CmAddFeat.Height = 20;
                        CmUseCase.IsEnabled = false;
                        CmFeature.IsEnabled = true;
                    }
                    else if (true == Equals(ItemName, usecase))
                    {
                        CmAddFeat.IsEnabled = true;
                        CmAddFeat.Height = 20;
                        CmFeature.IsEnabled = false;
                        CmUseCase.IsEnabled = true;
                    }
                    else
                    {
                        CmAddFeat.IsEnabled = false;
                        CmAddFeat.Height = 0;
                    }
                }
                TreeView1.ContextMenu = context;
                context.IsOpen = true;
            }

            catch (Exception)
            {
                if (selectedItem == null)
                {
                    (TreeView1.ItemContainerGenerator.ContainerFromIndex(0) as TreeViewItem).IsSelected = true;
                }

            }
        }


        public void ContextRename_Click(object sender, RoutedEventArgs e)
        {


            RenameItem();

        }




        private void DynamicTabControl_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }

        public void Button_Click_1(object sender, RoutedEventArgs e)
        {
            tab1.Items.RemoveAt(tab1.SelectedIndex);

        }

        private void TbNew_Drop(object sender, System.Windows.DragEventArgs e)
        {

        }

        private void TextBox_TextChanged(object sender, TextChangedEventArgs e)
        {

        }

        private void Hyperlink_RequestNavigate(object sender, RequestNavigateEventArgs e)
        {

        }

        private void ListBox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {


        }

        private void Hyperlink_click(object sender, RoutedEventArgs e)
        {
            Savediaglogbox();
        }

        private void Hyperlink_click1(object sender, RoutedEventArgs e)
        {
            Opendialogbox();
        }

        private void Search_Click(object sender, RoutedEventArgs e)
        {

        }

        private void TbCut_Click(object sender, RoutedEventArgs e)
        {

        }

        private void TreeView1_KeyDown(object sender, System.Windows.Input.KeyEventArgs e)
        {
            if (e.Key == Key.F2)
            {
                //System.Windows.Forms.MessageBox.Show("Alt + F2 pressed");
                RenameItem();
            }
        }

        private void CmAddFeatUse_Click(object sender, RoutedEventArgs e)
        {
           
            AddFeatUseCase();
        }

        private void _Click(object sender, RoutedEventArgs e)
        {

        }

        private void CmAddUseCase_Click(object sender, RoutedEventArgs e)
        {
         //   AddUseCaseWName();
        }

        private void TabItem_ToolTipOpening(object sender, ToolTipEventArgs e)
        {

        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {

        }


        private void Button_Click_1(object sender, MouseButtonEventArgs e)
        {
            tab1.Items.RemoveAt(tab1.SelectedIndex);

        }


        private void hyperlink_click(object sender, RoutedEventArgs e)
        {
            Savediaglogbox();
        }



        private void hyperlink_click1(object sender, RoutedEventArgs e)
        {
            Opendialogbox();
        }

        //public void Create_File()
        //{

        //    myfile = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), "RTE.afs");
        //    FileStream fs = new FileStream(myfile, FileMode.Create);

        //}
        private void Button_Click_2(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.Button b = sender as System.Windows.Controls.Button;
            string str = b.Tag.ToString();
            tab1.Items.Remove(tab1.SelectedItem);
           // Projects.Remove(str+"");
        }

        //context menu expand
        private void CmExpand_Click(object sender, RoutedEventArgs e)
        {
            if (TreeView1.SelectedItem == NewTreeItem)
            {
                if (TreeView1.SelectedItem == NewTreeItem && NewTreeItem.IsExpanded == false)
                {
                    NewTreeItem.IsExpanded = true;
                }
            }

           
            else if (TreeView1.SelectedItem == Feature)
            {
                if (TreeView1.SelectedItem == Feature && Feature.IsExpanded == false)
                {
                    Feature.IsExpanded = true;
                }
            }
           
        }
        //context menu collapse
        private void CmCollapse_Click(object sender, RoutedEventArgs e)
        {
            if (TreeView1.SelectedItem == NewTreeItem)
            {
                if (TreeView1.SelectedItem == NewTreeItem && NewTreeItem.IsExpanded == true)
                {
                    NewTreeItem.IsExpanded = false;
                }
            }

           

            else if (TreeView1.SelectedItem == Feature)
            {
                if (TreeView1.SelectedItem == Feature && Feature.IsExpanded == true)
                {
                    Feature.IsExpanded = false;
                }
            }
           
        }

       
        private void DockWindowGroup_MouseDoubleClick(object sender, MouseButtonEventArgs e)
        {

        }



        private void TbOpen_Click_1(object sender, RoutedEventArgs e)
        {
            Opendialogbox();
        }






       

        private void DataWindow_Closing(object sender, System.ComponentModel.CancelEventArgs e)
        {

            DialogResult dr = System.Windows.Forms.MessageBox.Show("Do you want to save your changes and exit?", "Functional Safety", MessageBoxButtons.YesNoCancel, MessageBoxIcon.Question);
            // user clicked yes
            if (dr == System.Windows.Forms.DialogResult.Yes)
            {
                Back_End b_end = new Back_End();
                b_end.SerializeAllData(); 
            }
            else if(dr == System.Windows.Forms.DialogResult.Cancel)
            {
                e.Cancel = true;

            }



        }

        private void ToolBar_Loaded(object sender, RoutedEventArgs e)
        {
            System.Windows.Controls.ToolBar toolBar = sender as System.Windows.Controls.ToolBar;
            var overflowGrid = toolBar.Template.FindName("OverflowGrid", toolBar) as FrameworkElement;
            if (overflowGrid != null)
            {
                overflowGrid.Visibility = Visibility.Collapsed;
            }
            var mainPanelBorder = toolBar.Template.FindName("MainPanelBorder", toolBar) as FrameworkElement;
            if (mainPanelBorder != null)
            {
                mainPanelBorder.Margin = new Thickness();
            }
        }

       

        private void TreeView1_OnSelected(object sender, RoutedEventArgs e)
        {
            ////TreeView1.Tag = e.OriginalSource;
           // System.Windows.MessageBox.Show((TreeView1.SelectedItem as Sheets).Header);
        }

        private void Button_Click(object sender, RoutedEventArgs e)
        {
            FeatureWithUsecase f = new FeatureWithUsecase();
            f.Show();
        }

        private void Button_Click_3(object sender, RoutedEventArgs e)
        {
            var activity = TreeView1.SelectedItem as Project;
            activity.ActivityCollection.Add(new Selectactivity { Header = "Sample from button 3" });
        }

        private void tsearch_Click(object sender, RoutedEventArgs e)
        {
            
            var obj = TreeView1.SelectedItem as Project;
            var items = new ObservableCollection<Project>();


            // var onj1 = (TreeView1.SelectedItem as Project);
            //ObservableCollection<Project> p = new ObservableCollection<Project>();

              //System.Windows.MessageBox.Show(Mainproject.items.Count+"");
              //for (int i=0;i<Mainproject.items.Count;i++)
              //{
              //    if(Mainproject.items[i].Equals(obj))
              //    {
              //        Mainproject.items.Remove(obj);
              //        System.Windows.MessageBox.Show(obj+"");
              //    }
              //    else
              //    {
              //       // System.Windows.MessageBox.Show("Found No Match");
              //    }
              //}

              //< HierarchicalDataTemplate x: Key = "FeatureTemplate" DataType = "{x:Type local:Feature}" ItemsSource = "{Binding UseCaseCollection}" >

              //     < StackPanel Orientation = "Horizontal" >

              //          < Image Source = "./resources/file.png" Width = "15" Height = "15" />

              //               < TextBlock Text = "{Binding Header}" />

              //            </ StackPanel >

              //        </ HierarchicalDataTemplate >

              //< TextBlock TextWrapping = "Wrap" Text = "Project Browser" Height = "20" Background = "DeepSkyBlue" FontWeight = "Bold" FontFamily = "Calibri" FontSize = "16" />
             
              //           < local:CustomTreeViewItem x:Name = "FunctionalSafetyTv" Header = "Functional Safety" >
                

              //              </ local:CustomTreeViewItem >
        }
    }
   
}

