﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FS_1
{
    public class Global
    {

        public static string new_toolname = null;
        public static int check1 = 0;
        public static int check2 = 0;
        public static string filename = null;
        public static string filename_without_extension = null;
        public static string toolname = null;
        public static SummaryViewModel summary = new SummaryViewModel();
        public static Tool_Details details = new Tool_Details();

    }
}
