﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;

namespace FS_1
{
    public class Back_End
    {

          Functional_Safety f1 = new Functional_Safety();
        Project p1 = new Project();
        Selectactivity tool_obj = new Selectactivity();
        Tool tool_element = new Tool();
        Sheets Details = new Sheets();
        public static SummaryViewModel summary_obj = null;
        public static Tool_Details tooldetails_obj = null;



        public void CreateProjectObjects()
        {
           /* System.Windows.MessageBox.Show("entered");

            foreach (var value in f1.ProjectCollection)
            {
                System.Windows.MessageBox.Show(value.Header);
            }*/
        }

        public void CreateTclObjects()
        {
            //MessageBox.Show("Entered");

            tool_element.ToolName = Global.toolname;



        }

        //Function to store Summary
        public SummaryViewModel CreateSummaryObjects(SummaryViewModel get_data)
        {
            //MessageBox.Show("Entered");

            summary_obj = get_data;
            return get_data;
        }

        //Function to store Tool Details 
        public Tool_Details CreateToolDetailsObjects(Tool_Details get_data)
        {

            tooldetails_obj = get_data;
            return get_data;
        }

        //Function to serialize and encrpyt all the data entered
        public void SerializeAllData()
        {
            CreateProjectObjects();
            CreateTclObjects();
            Details.SummaryObjects = summary_obj;
            Details.ToolDetailsObjects = tooldetails_obj;
            //serialize and encrypt
            Serialize elements = new Serialize();
            elements.Serializer(p1);
            //decrypt         
            Decryption decrypt_data = new Decryption();
            decrypt_data.Decrypter();

        }

       
    }

}







