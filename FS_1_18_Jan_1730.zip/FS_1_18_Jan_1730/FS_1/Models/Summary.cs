﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FS_1.Models
{
    public class Summary : ModelBase
    {
        private string _projectName;
        public string ProjectName
        {
            get { return _projectName; }
            set
            {
                _projectName = value;
                OnPropertyChanged("ProjectName");
            }
        }

        private string _customerName;
        public string CustomerName
        {
            get { return _customerName; }
            set
            {
                _customerName = value;
                OnPropertyChanged("CustomerName");
            }
        }

        private string _projectManager;
        public string ProjectManager
        {
            get { return _projectManager; }
            set
            {
                _projectManager = value;
                OnPropertyChanged("ProjectManager");
            }
        }

        private string _toolName;
        public string ToolName
        {
            get { return _toolName; }
            set
            {
                _toolName = value;
                OnPropertyChanged("ToolName");
            }
        }

        private string _toolVersionNo;
        public string ToolVersionNo
        {
            get { return _toolVersionNo; }
            set
            {
                _toolVersionNo = value;
                OnPropertyChanged("ToolVersionNo");
            }
        }
        private string _documentId;
        public string DocumentId
        {
            get { return _documentId; }
            set
            {
                _documentId = value;
                OnPropertyChanged("DocumentId");
            }
        }
        private string _documentVersionNo;
        public string DocumentVersionNo
        {
            get { return _documentVersionNo; }
            set
            {
                _documentVersionNo = value;
                OnPropertyChanged("DocumentVersionNo");
            }
        }
        private string _date;
        public string Date
        {
            get { return _date; }
            set
            {
                _date = value;
                OnPropertyChanged("Date");
            }
        }
        private string _documentOverview;
        public string DocumentOverview
        {
            get { return _documentOverview; }
            set
            {
                _documentOverview = value;
                OnPropertyChanged("DocumentOverview");
            }
        }
        /*  TreeViewItem AddSummaryToTool;
         public string ProjectName { get; set; }
         public string CustomerName { get; set; }
         public string ProjectManager { get; set; }
         public string ToolName { get; set; }
         public string ToolVersionNo { get; set; }
         public string DocumentId { get; set; }
         public string DocumentVersionNo { get; set; }
         public string Date { get; set; }
         public string DocumentOverview { get; set; }*/

        //public void AddSummary(Tool ParentNode)
        //{
        //    AddSummaryToTool = new TreeViewItem { Header = "Summary", UId =""};
        //    ParentNode.Items.Add(AddSummaryToTool);
        //}
    }
}
