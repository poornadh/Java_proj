﻿using System;
using System.Collections.Generic;
using System.IO;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FS_1
{
    /// <summary>
    /// Interaction logic for UserControl1.xaml
    /// </summary>
    public partial class UserControl1 : UserControl
    {
        public UserControl1()
        {
            InitializeComponent();
            load();
            // loadbydate();
        }

        public void load()
        {
            //Label lab = new Label();
            //lab.Content = "Recent Files";
            //lab.HorizontalContentAlignment = HorizontalAlignment.Center;
            //lab.MinHeight = 20;
            //lab.FontSize = 14;
            //lab.FontWeight = FontWeights.Bold;
            //listbox.Items.Add(lab);
            DirectoryInfo di = new DirectoryInfo(@"D:\Visual Studio Working Files");
            foreach (FileInfo fi in di.GetFiles("*.afs").OrderByDescending(d => d.LastWriteTime))
                listbox.Items.Add(fi.Name.Substring(0, fi.Name.Length - 4));
        }
        
        /*  private void Button_Click(object sender, RoutedEventArgs e)
          {

              var file = Directory.GetFiles(@"C:\Users\hardhik.isarapu\Documents", "*.afs")
                                      .Select(f => new FileInfo(f))
                                      .OrderByDescending(fi => fi.LastWriteTime)
                                      .First()
                                      .FullName;
              string files = System.IO.Path.GetFileName(file);
              listbox.Items.Add(files);

          }*/

        private void Hyperlink_click(object sender, RoutedEventArgs e)
        {
            System.Windows.Application.Current.Windows.OfType<MainWindow>().SingleOrDefault(x => x.IsActive).Opendialogbox();
        }

        private void Hyperlink_click1(object sender, RoutedEventArgs e)
        {
            System.Windows.Application.Current.Windows.OfType<MainWindow>().SingleOrDefault(x => x.IsActive).Savediaglogbox();
        }

        private void openproject_MouseEnter(object sender, MouseEventArgs e)
        {

        }

        private void listbox_SelectionChanged(object sender, SelectionChangedEventArgs e)
        {

        }
    }
}
