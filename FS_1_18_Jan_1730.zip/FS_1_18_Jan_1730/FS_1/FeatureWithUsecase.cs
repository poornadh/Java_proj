﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FS_1
{
    public partial class FeatureWithUsecase : Form
    {
        public FeatureWithUsecase()
        {
            InitializeComponent();
            dataGridView1.Rows.Add();
            
        }

        private void addnewrow_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add();
        }

        private void button1_Click(object sender, EventArgs e)
        {
            this.Close();
        }

        private void dataGridView1_RowPrePaint(object sender, DataGridViewRowPrePaintEventArgs e)
        {
            String dgvheader = String.Format("{0}", e.RowIndex + 1);

            if (dataGridView1.Rows[e.RowIndex].HeaderCell.Value == null || dgvheader != dataGridView1.Rows[e.RowIndex].HeaderCell.Value.ToString())
            {
                dataGridView1.Rows[e.RowIndex].HeaderCell.Value = dgvheader;
            }
        }

        private void Treeform_AfterSelect(object sender, TreeViewEventArgs e)
        {

        }

        private void Add_Button_Click(object sender, EventArgs e)
        {
            dataGridView1.Rows.Add();
        }

        private void Delete_button_Click(object sender, EventArgs e)
        {
            foreach (DataGridViewRow dg in dataGridView1.SelectedRows)
            {

                dataGridView1.Rows.RemoveAt(dg.Index);
            }
        }

        private void Search_button_Click(object sender, EventArgs e)
        {
            string str = searchbox.Text;
            dataGridView1.SelectionMode = DataGridViewSelectionMode.FullRowSelect;
            try
            {
                bool valueResult = false;
                foreach (DataGridViewRow row in dataGridView1.Rows)
                {
                    for (int i = 0; i < row.Cells.Count; i++)
                    {
                        if (row.Cells[i].Value != null && row.Cells[i].Value.ToString().Contains(str))
                        {
                            int rowIndex = row.Index;
                            dataGridView1.Rows[rowIndex].Selected = true;
                            valueResult = true;
                            //errorProvider1.Clear();
                            break;
                        }
                    }

                }
                if (!valueResult)
                {
                   // errorProvider1.SetError(error_label, "Unable to Find Your Search");
                    return;
                }
            }
            catch (Exception exc)
            {
                MessageBox.Show(exc.Message);
            }
        }

        private void searchbox_TextChanged(object sender, EventArgs e)
        {
            //errorProvider1.Clear();
        }
    }
}
