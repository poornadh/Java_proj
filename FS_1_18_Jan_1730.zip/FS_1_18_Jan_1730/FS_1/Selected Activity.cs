﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Windows.Forms;
using System.Windows.Controls;

namespace FS_1
{
    public class Selectactivity : CustomTreeViewItem
    {
        public Selectactivity()
        {
            this.ToolsCollection = new ObservableCollection<Tool>();
        }

        
        private ObservableCollection<Tool> _toolsCollection;
        public ObservableCollection<Tool> ToolsCollection
        {
            get { return _toolsCollection; }
            set
            {
                if (_toolsCollection != value)
                {
                    _toolsCollection = value;
                    OnPropertyChanged("ToolsCollection");
                }
            }
        }


        public new string Header { get; set; }

        public TreeViewItem AddSA(TreeViewItem ParentNode)
        {
            TreeViewItem AddSA = new TreeViewItem { Header = "Analysis_Name", Uid =""};
            ParentNode.Items.Add(AddSA);
            return AddSA;
        }
    }
}
