﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Navigation;
using System.Windows.Shapes;

namespace FS_1
{
    /// <summary>
    /// Interaction logic for wpftooldetails.xaml
    /// </summary>
    public partial class wpftooldetails : UserControl
    {
        public string encrypted_string2 = null;
        public wpftooldetails()
        {
            InitializeComponent();
        }

        private void Clear_Option_Tool(object sender, RoutedEventArgs e)
        {
            name.Clear();
            vendorname.Clear();
            versionNo.Clear();
            usage.Clear();
            purchase.Clear();
            installation.Clear(); warranty.Clear(); purpose.Clear(); projectinputs.Clear(); usermanuals.Clear(); testreports.Clear();

        }


        private void Save_Option_Tool(object sender, RoutedEventArgs e)
        {
            Tool_Details details = new Tool_Details();
            details.Name = name.Text;
            details.VendorName = vendorname.Text;
            details.VersionNo = versionNo.Text;
            details.UsageEnvironment = usage.Text;
            details.PurchaseDate = purchase.Text;
            details.InstallationDate = installation.Text;
            details.MaintenanceContract = warranty.Text;
            details.Purpose = purpose.Text;
            details.ProjectInputs = projectinputs.Text;
            details.UserManuals = usermanuals.Text;
            details.TestReports = testreports.Text;

            Back_End b_end = new Back_End();
            b_end.CreateToolDetailsObjects(details);

           
            Global.check2++;
        }


        private void Button_ToolTipOpening(object sender, ToolTipEventArgs e)
        {

        }
    }
}
