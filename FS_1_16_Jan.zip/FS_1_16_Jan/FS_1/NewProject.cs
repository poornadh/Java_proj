﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace FS_1
{
    public partial class NewProject : Form
    {
        public NewProject()
        {
            InitializeComponent();
        }

        

        private void NewProject_Load(object sender, EventArgs e)
        {
            panel3.Visible = false; 
            panel2.Visible = true; 
            
            
        }




        
        private void Button1_Click_1(object sender, EventArgs e)
        {
            //form for TCL
            if (listBox1.SelectedIndex == 0)
            {
                if (textBox1.Text == "")
                {
                    errorProvider1.SetError(textBox1, "Mandatory Field");//to show the textbox is empty

                }
                else if (textBox2.Text == "")
                {
                    errorProvider2.SetError(textBox2, "Mandatory Field");//to show the textbox is empty

                }
                else
                {
                    this.DialogResult = DialogResult.OK;
                    Back_End b_end = new Back_End();
                  //  Project create_proj = b_end.CreateProjectObjects();
                   
                    this.Close();
                }
            }
            //Form for TQ
            if (listBox1.SelectedIndex == 1)
            {
                if (textBox1.Text == "")
                {
                    errorProvider1.SetError(textBox1, "Mandatory Field");//to show the textbox is empty

                }
                else if (textBox2.Text == "")
                {
                    errorProvider2.SetError(textBox2, "Mandatory Field");//to show the textbox is empty

                }
                else
                {
                    DialogResult = DialogResult.OK;
                   

                    this.Close();
                }
            }
            //Form for SA
             if(listBox1.SelectedIndex==2)
            {
                if (textBox1.Text == "")
                {
                    errorProvider1.SetError(textBox1, "Mandatory Field");//to show the textbox is empty

                }
                else
                {
                    DialogResult = DialogResult.OK;
                 

                    this.Close();
                }
            }

        }

        private void Button2_Click_1(object sender, EventArgs e)
        {
            //try
            //{
            //    this.DialogResult = DialogResult.Cancel;
            //    this.Close();
            //}
            //   catch(Exception)
            //{
            //    listBox1.SelectedIndex = 0;
            //}

            this.DialogResult = DialogResult.Cancel;
            this.Close();

        }

       
       

        //Respective Panel will appear with the selected listbox item
        private void listBox1_SelectedIndexChanged(object sender, EventArgs e)
        {
            if (listBox1.SelectedIndex == 0)
            {
                panel3.Visible = true ;
                label3.Show();
                label4.Show();
                
                textBox1.Show();
                textBox2.Show();
               
                
            }
            else if (listBox1.SelectedIndex == 1)
            {
                panel3.Visible=true;
                label3.Show();
                label4.Show();
               
                textBox1.Show();
                textBox2.Show();
               
                
            }
            else if (listBox1.SelectedIndex == 2)
            {
                panel3.Visible=true;
                label3.Show();
                label4.Hide();
               
                textBox1.Show();
                textBox2.Hide();
                
                
            }
           
        }

        private void textBox1_TextChanged(object sender, EventArgs e)
        {
            errorProvider1.Clear();
        }

        private void textBox2_TextChanged(object sender, EventArgs e)
        {
            errorProvider2.Clear();
        }

       

        private void panel4_Paint(object sender, PaintEventArgs e)
        {

        }

        private void listBox1_SelectedValueChanged(object sender, EventArgs e)
        {
           
        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void label6_Click(object sender, EventArgs e)
        {

        }

        private void textBox2_TextChanged_1(object sender, EventArgs e)
        {

        }

        private void textBox4_TextChanged(object sender, EventArgs e)
        {

        }

        private void textBox3_TextChanged(object sender, EventArgs e)
        {

        }
    }
}
