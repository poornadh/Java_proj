﻿using Newtonsoft.Json;
using Newtonsoft.Json.Converters;
using System;
using System.IO;
using System.Text;
using System.Windows;

namespace FS_1
{
    public class Serialize
    {
        public string Serialized_string;
        public string Encrypted_string;
        public string myfile;
      
        //Json Serializer
        //Passed data is serialized and stored in string
        public void Serializer(object data)
        {
           
            Serialized_string = JsonConvert.SerializeObject(data, new KeyValuePairConverter());
          //  MessageBox.Show(Serialized_string);
           // Serialized_string = JsonConvert.SerializeObject(data);

            //calling encryption function in encrypter class
            //create an object of encryption class
           FS_1.Encryption encryption = new Encryption();
            Encrypted_string = encryption.EncryptLogger(Serialized_string);

            //storing the string in file
            byte[] byte_encrypted = Encoding.ASCII.GetBytes(Encrypted_string);
          


            // MainWindow mw = new MainWindow();
            myfile = System.IO.Path.Combine(Environment.GetFolderPath(Environment.SpecialFolder.MyDocuments), Global.filename);
            if (!File.Exists(myfile))
            {

                FileStream fs1 = new FileStream(myfile, FileMode.Create);
                fs1.Write(byte_encrypted, 0, byte_encrypted.Length);
                //pos =(int) fs1.Position;
                //MessageBox.Show(pos.ToString());
                fs1.Close();
            }
            else
            {

                using (FileStream fs1 = new FileStream(myfile, FileMode.Append, FileAccess.Write))
                {
                    fs1.Write(byte_encrypted, 0, byte_encrypted.Length);
                    fs1.Close();

                }

            }

        }      
    }
}
       
    

