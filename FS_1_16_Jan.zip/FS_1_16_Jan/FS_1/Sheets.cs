﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Windows.Forms;
using System.Windows.Controls;

namespace FS_1
{
    public class Sheets : CustomTreeViewItem
    {
        public Sheets()
        {
            //This.items = new ObservableCollection<Details>();
        }
        //blic string Header { get; set; }
        private ObservableCollection<Sheets> _sheetsCollection;
        public ObservableCollection<Sheets> SheetsCollection
        {
            get { return _sheetsCollection;}
            set
            {
                if (_sheetsCollection != value)
                {
                    _sheetsCollection = value;
                    OnPropertyChanged("SheetsCollection");
                }
                }
        }

        public Summary SummaryObjects = new Summary() { Header = "Project_Name", ProjectName = "Project_Name", CustomerName = "--", ProjectManager = "<To be filled>" };
        public Revision_history RevisionHistoryObjects = new Revision_history() { Header = "Revision_history" };
        public Abbreviations AbbrevationObjects = new Abbreviations() { Header = "Abbrevations" };
        public Tool_Details ToolDetailsObjects = new Tool_Details() { Header = "Tool_Details", ToolName = "<e.g RTE TestCaseGenerator>" };
        public Analysis_Summary AnalysisSummaryObjects = new Analysis_Summary() { Header = "Analysis Summary", TCLLevel="<TCL1/TCL2/TCL3>"};
        public Feature FeatureObjects = new Feature(); // features
        public TemplateRevisionHistory TemplateRevisionHistoryObjects;
        public Tool Ins_Tool = new Tool();

        
        public void AddToTool (Feature ToAddFeature)
        {
            //ParentNode = new TreeViewItem { Header = ToAddFeature.Header, Uid = "" };
            //ParentNode.Items.Add(ToAddFeature);
            //items.Add((Details)SummaryObjects);

        }
    }
}
