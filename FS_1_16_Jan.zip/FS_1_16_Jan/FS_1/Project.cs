﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Collections.ObjectModel;
using System.Reflection;
using System.Windows.Forms;
using System.Windows.Controls;
using FS_1.Properties;

namespace FS_1
{

    public class Project : CustomTreeViewItem, IProject
    {
        public Project()
        {
            this.ActivityCollection = new ObservableCollection<Selectactivity>();
        }

        private ObservableCollection<Selectactivity> _activityCollection { get; set; }
        public ObservableCollection<Selectactivity> ActivityCollection
        { get { return _activityCollection; }
            set {
                if (_activityCollection != value)
                {
                    _activityCollection = value;
                    OnPropertyChanged("ActivityCollection");
                }
            }
        }
        List<String> DefaultItems = new List<String>() { "Summary", "Tool Details", "Revision History", "Analysis Summary", "Features" };



        public void createDefaultSheets()
        {
            System.Windows.Forms.MessageBox.Show("Entered!!! ");
            //var AddProjectToParent = AddProject(ParentItem);
            //Selectactivity SA = AddChild()
            //this.Members.Add(new CustomTreeViewItem() { Header = ParentItem.Header });
            //this.Members.Add(new CustomTreeViewItem() { Header = }
            foreach (String sheet in DefaultItems)
            {
                System.Windows.Forms.MessageBox.Show("Entered = " + sheet + ActivityCollection.Count, sheet);
                CustomTreeViewItem iter = new CustomTreeViewItem() { Header = sheet, Uid = "" };
               // this.Members.Add(iter);
            }

            //CustomTreeViewItem Summary = new CustomTreeViewItem() { Header = "Summary", Uid = "" };
            //CustomTreeViewItem iter = new CustomTreeViewItem() { Header = "Summary", Uid = "" };
            //CustomTreeViewItem iter = new CustomTreeViewItem() { Header = "Summary", Uid = "" };
            //CustomTreeViewItem iter = new CustomTreeViewItem() { Header = "Summary", Uid = "" };
            //this.Members.Add(iter);
        }


        public CustomTreeViewItem AddProject(CustomTreeViewItem ParentItem, int treeViewItemCount)
        {
            if (treeViewItemCount == 0)
            {
                CustomTreeViewItem NewProjectToParent = new CustomTreeViewItem { Header = "Project_Name", Uid = "" };

                return NewProjectToParent;
            }
            else
            {
                MessageBox.Show("Entered treeviewitemcount is greaterr than zero");
                CustomTreeViewItem AddProjectToParent = new CustomTreeViewItem { Header = "Project_Name", Uid = "" };
               // Members.Add(AddProjectToParent);
                return AddProjectToParent;
            }
        }

        public void AddNode(TreeViewItem ParentNode)
        {
            throw new NotImplementedException();
        }

        public TreeViewItem PopulateNode(TreeViewItem ParentNode)
        {
            throw new NotImplementedException();
        }

        public void PopulateNodeNoReturn(TreeViewItem ParentNode)
        {
            throw new NotImplementedException();
        }

        public void ClearOneNode(int a)
        {
            throw new NotImplementedException();
        }

        public void populateChilds(int a)
        {
            throw new NotImplementedException();
        }
    }
    //public class CustomTreeviewClass : TreeViewItem,MainWindow
    //    {
    //        Functional_Safety.

    //    }

    //public class Project : TreeViewItem,IProject
    //{
    //    public Project()
    //    {
    //        this.Members = new ObservableCollection<CustomTreeViewItem>();
    //    }

    //    public ObservableCollection<CustomTreeViewItem> Members { get; set; }

    //    ////To add treeviewitems : To be Completed
    //    //public void Project_add(ObservableCollection<Project> data, TreeViewItem ParentNode)
    //    //{
    //    //    ParentNode.Items.Add(data);
    //    //}

    //    //public string header { get; set; }

    //    //public void SetName(string value) => header = value;

    //    //public string GetName() => header;


    //    //public ObservableCollection<Selectactivity> items { get; set; }
    //    //public Selectactivity tcl = new Selectactivity(); //create list of TCL project names



    //    // public void Repl(Object o,string propertyName,string latestValue)
    //    // {
    //    //    Type type = o.GetType();
    //    //    PropertyInfo i= type.GetProperty(propertyName);
    //    //     i.SetValue(o, latestValue);
    //    // }

    //    //public void sete()
    //    // {
    //    //     Project p = new Project();
    //    //     Repl(p, "project_name", "A");  

    //    //     Feature f = new Feature();
    //    //     Repl(f, "Use_Cases", "s");
    //    // }

    //    // public Project CreateInstance()
    //    // {
    //    //     return new Project();
    //    // }
    //    List<String> DefaultItems = new List<string>() { "Summary", "Tool Details", "Revision History", "Analysis Summary", "Features"};

    //    public void createDefaultSheets()
    //    {

    //    }


    //    public TreeViewItem AddProject(TreeViewItem ParentNode)
    //    {
    //        CustomTreeViewItem AddProjectToParent = new CustomTreeViewItem { Header = "Project_Name", Uid =""};
    //        ParentNode.Items.Add(AddProjectToParent);
    //        return AddProjectToParent;
    //    }

    //    public void AddNode(TreeViewItem ParentNode)
    //    {
    //        throw new NotImplementedException();
    //    }

    //    public TreeViewItem PopulateNode(TreeViewItem ParentNode)
    //    {
    //        throw new NotImplementedException();
    //    }

    //    public void PopulateNodeNoReturn(TreeViewItem ParentNode)
    //    {
    //        throw new NotImplementedException();
    //    }

    //    public void ClearOneNode(int a)
    //    {
    //        throw new NotImplementedException();
    //    }

    //    public void populateChilds(int a)
    //    {
    //        throw new NotImplementedException();
    //    }
    //}
}
