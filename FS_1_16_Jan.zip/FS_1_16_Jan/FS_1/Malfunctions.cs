﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace FS_1
{
    public class Malfunctions : CustomTreeViewItem
    {
        private string _header;
        public new string Header
        {
            get { return _header; }
            set
            {
                if (_header != value)
                    _header = value;
                OnPropertyChanged("Header");
            }
        }

        private string _toolImpact;
        public string ToolImpact
        {
            get { return _toolImpact; }
            set
            {
                if (_toolImpact != value)
                    _toolImpact = value;
                OnPropertyChanged("ToolImpact");
            }
        }

        private string _reasonForTI;
        public string ReasonForTI {
            get {return _reasonForTI; }
            set
            {
                if (_reasonForTI != value)
                    _reasonForTI = value;
                OnPropertyChanged("ReasonForTI");
            }
        }

        private string _toolDetection;
        public string ToolDetection
        {
            get { return _toolDetection; }
            set
            {
                if (_toolDetection != value)
                    _toolDetection = value;
                OnPropertyChanged("ToolDetection");
            }
        }

        private string _reasonForTD;
        public string ReasonForTD
        {
            get { return _reasonForTD; }
            set
            {
                if (_reasonForTD != value)
                    _reasonForTD = value;
                OnPropertyChanged("ReasonForTD");
            }
        }

        private string _tCLLevel;
        public string TCLLevel
        {
            get { return _tCLLevel; }
            set
            {
                if (_tCLLevel != value)
                    _tCLLevel = value;
                OnPropertyChanged("TCLLevel");
            }
        }
    }
}
