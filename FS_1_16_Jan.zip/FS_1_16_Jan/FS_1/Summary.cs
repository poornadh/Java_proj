﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Controls;

namespace FS_1
{
    public class Summary: CustomTreeViewItem
    {   
        TreeViewItem AddSummaryToTool;
        public string ProjectName { get; set; }
        public string CustomerName { get; set; }
        public string ProjectManager { get; set; }
        public string ToolName { get; set; }
        public string ToolVersionNo { get; set; }
        public string DocumentId { get; set; }
        public string DocumentVersionNo { get; set; }
        public string Date { get; set; }
        public string DocumentOverview { get; set; }

        public void AddSummary(Tool ParentNode)
        {
            AddSummaryToTool = new TreeViewItem { Header = "Summary", Uid =""};
            ParentNode.Items.Add(AddSummaryToTool);
        }
    }
}
