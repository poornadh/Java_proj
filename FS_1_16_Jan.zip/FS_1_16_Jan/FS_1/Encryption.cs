﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Security.Cryptography;
using System.IO;
using System.Text.RegularExpressions;


namespace FS_1
{
    public class Encryption
    {
        public string myfile1;
        public string EncryptLogger(string plainText)
        {
            
            try
            {
                if (plainText == null || plainText.Length <= 0) return plainText;

                var rijAlg = NewRijndaelManaged();
                ICryptoTransform encryptor = rijAlg.CreateEncryptor(rijAlg.Key, rijAlg.IV);
                // Create the streams used for encryption.
                MemoryStream msEncrypt = new MemoryStream();
                CryptoStream csEncrypt = new CryptoStream(msEncrypt, encryptor, CryptoStreamMode.Write);
                StreamWriter swEncrypt = new StreamWriter(csEncrypt);
                //Write all data to the stream.

                swEncrypt.Write(plainText);
                swEncrypt.Close();
               
                plainText = Convert.ToBase64String(msEncrypt.ToArray());
            }//End of try
            catch
            {
                //Exception is not handled
            }//End of catch
            return plainText;
        }//End of EncryptLogger

        public static bool IsBase64String(string base64String)
        {
            base64String = base64String.Trim();
            return (base64String.Length % 4 == 0) && Regex.IsMatch(base64String, @"^[a-zA-Z0-9\+/]*={0,3}$", RegexOptions.None);

        }

        private static RijndaelManaged NewRijndaelManaged()
        {
            var saltBytes = Encoding.ASCII.GetBytes(FS_1.Properties.Resources.password);
            var key = new Rfc2898DeriveBytes(FS_1.Properties.Resources.InputKey, saltBytes);
            var aesAlg = new RijndaelManaged();
            aesAlg.Key = key.GetBytes(aesAlg.KeySize / 8);
            aesAlg.IV = key.GetBytes(aesAlg.BlockSize / 8);
            return aesAlg;
        }//End of NewRijndaelManaged
    }
}



